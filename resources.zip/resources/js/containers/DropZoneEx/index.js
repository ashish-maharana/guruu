import React, { useMemo, useEffect, useState } from "react";
import ReactDOM from "react-dom";
import { useDropzone } from "react-dropzone";

const baseStyle = {
  flex: 1,
  display: "flex",
  flexDirection: "row",
  alignItems: "center",
};

const activeStyle = {
  borderColor: "#2196f3"
};

const acceptStyle = {
  borderColor: "#00e676"
};

const rejectStyle = {
  borderColor: "#ff1744"
};

const thumbsContainer = {
  display: "flex",
  flexDirection: "row",
  flexWrap: "wrap",
  marginTop: 16
};

const thumb = {
  display: "inline-flex",
  borderRadius: 2,
  border: "1px solid #eaeaea",
  marginBottom: 8,
  marginRight: 8,
  width: "auto",
  height: 200,
  padding: 4,
  boxSizing: "border-box"
};

const thumbInner = {
  display: "flex",
  minWidth: 0,
  overflow: "hidden"
};

const img = {
  display: "block",
  width: "auto",
  height: "100%"
};

export default function StyledDropzone(props) {
  const [files, setFiles] = useState([]);
  const {
    getRootProps,
    getInputProps,
    isDragActive,
    isDragAccept,
    isDragReject,
    acceptedFiles,
    open
  } = useDropzone({
    accept: "image/*",
    noClick: true,
    noKeyboard: true,
    multiple: false, 
    onDrop: acceptedFiles => {
      setFiles(
        acceptedFiles.map(file =>
          Object.assign(file, {
            preview: URL.createObjectURL(file)
          })
        )
      );
    }
  });

  const style = useMemo(
    () => ({
      ...baseStyle,
      ...(isDragActive ? activeStyle : {}),
      ...(isDragAccept ? acceptStyle : {}),
      ...(isDragReject ? rejectStyle : {})
    }),
    [isDragActive, isDragReject]
  );

  const thumbs = files.map(file => (
    <div className="image-previewer" style={thumb} key={file.name} style={{backgroundImage: `url(${file.preview})` }}>
      {/* <div style={thumbInner} >
        <img src={file.preview} style={img} />
      </div> */}
    </div>
  ));

  const remove = file => {
    const newFiles = [...files];     // make a var for the new array
    acceptedFiles.splice(file, 1); 
    files.splice(file);  // remove the file from the array
  };

  const filepath = acceptedFiles.map((file, i) => (
    <li key={file.path}>
      {file.path} - {file.size} bytes
      <a className="text-red" onClick={() => remove(i)}><i className="bi bi-trash"></i></a>
    </li>
  ));

  return (
      <div className="image-uploader py-3" onClick={open}>
        <div {...getRootProps({ style })}>
          <div className="img-preview-box">
            <div className="preview d-flex align-items-center">
              <div className="w-100 text-center">
                <i className="bi bi-cloud-arrow-up"></i>
                <input {...getInputProps()} />
                <p>Drag & drop</p>
              </div>
              <div className="upload-profile">{thumbs}</div>
            </div>
          </div>
          <div className="ps-5">
            <button className="btn btn-warning rounded-pill py-2 px-4 img-upload-btn">Upload</button>
            <div className="img-upload-info mt-3">Jpg or png / size: 5 MB max.</div>
            <ul className="filename">{filepath}</ul>
          </div>
        </div>
      </div>
  );
}

ReactDOM.render(<StyledDropzone />, document.getElementById("root"));