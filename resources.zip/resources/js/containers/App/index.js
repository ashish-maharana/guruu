/**
 *
 * App.js
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 *
 */

import React from 'react';
import {
    BrowserRouter,
    Routes,
    Route,
    Link
} from "react-router-dom";

import HomePage from "../HomePage";
import NotFoundPage from "../NotFoundPage";
import Login from '../Login';
import ForgotPassword from '../Login/forgotPassword';
import ResetPassword from '../Login/resetPassword';
import ProtectedRoute from "./ProtectedRoute";
import PublicRoute from "./PublicRoute";
import Users from '../Users';
import AddUser from '../AddUser'
import EditUser from "../EditUser";
import Roles from '../Roles';
import AddRole from '../AddRole'
import EditRole from "../EditRole";
import Permissions from '../Permissions';
import AddPermission from '../AddPermission'
import EditPermission from "../EditPermission";
import Category from '../Category';
import AddCategory from '../AddCategory'
import EditCategory from "../EditCategory";
import TrackType from '../TrackTypes';
import AddTrackType from '../AddTrackTypes'
import EditTrackType from "../EditTrackTypes";
import About from "../About";
import LcStorage from '../../utils/LcStorage'
import MyAccount from '../MyAccount';
import Dashboard from '../Dashboard';
import SearchResult from '../SearchResult';
import { ToastContainer, toast } from 'react-toastify';
import ResetPasswordConfirmation from '../Login/ResetPasswordConfirmation';
import SignUp from '../SignUp/multistepform';


export default function App() {
  let authenticated = LcStorage.get('token');
  return (
      <div className="h-100">
        <BrowserRouter>
          <Routes>
            <Route exact path="/" element={<HomePage />} />
            <Route exact path={"/about"} element={<ProtectedRoute><About /></ProtectedRoute>} />
            <Route exact path="/login" element={<PublicRoute><Login /></PublicRoute>} />
            <Route exact path="/register" element={<PublicRoute><SignUp /></PublicRoute>} />
            <Route exact path="/forgot-password" element={<PublicRoute><ForgotPassword /></PublicRoute>} />
            <Route exact path="/:token/reset-password" element={<PublicRoute><ResetPassword /></PublicRoute>} />
            <Route exact path={"/users"} element={<ProtectedRoute><Users /></ProtectedRoute>} />
            <Route exact path="/users/add" element={<ProtectedRoute><AddUser /></ProtectedRoute>} />
            <Route exact path="/users/edit/:id" element={<ProtectedRoute><EditUser /></ProtectedRoute>} />
            <Route exact path={"/roles"} element={<ProtectedRoute><Roles /></ProtectedRoute>} />
            <Route exact path="/roles/add" element={<ProtectedRoute><AddRole /></ProtectedRoute>} />
            <Route exact path="/roles/edit/:id" element={<ProtectedRoute><EditRole /></ProtectedRoute>} />
            <Route exact path={"/permissions"} element={<ProtectedRoute><Permissions /></ProtectedRoute>} />
            <Route exact path="/permissions/add" element={<ProtectedRoute><AddPermission /></ProtectedRoute>} />
            <Route exact path="/permissions/edit/:id" element={<ProtectedRoute><EditPermission /></ProtectedRoute>} />
            <Route exact path={"/category"} element={<ProtectedRoute><Category /></ProtectedRoute>} />
            <Route exact path="/category/add" element={<ProtectedRoute><AddCategory /></ProtectedRoute>} />
            <Route exact path="/category/edit/:id" element={<ProtectedRoute><EditCategory /></ProtectedRoute>} />
            <Route exact path={"/tracktypes"} element={<ProtectedRoute><TrackType /></ProtectedRoute>} />
            <Route exact path="/tracktypes/add" element={<ProtectedRoute><AddTrackType /></ProtectedRoute>} />
            <Route exact path="/tracktypes/edit/:id" element={<ProtectedRoute><EditTrackType /></ProtectedRoute>} />
            <Route path="*" element={<NotFoundPage />} /> 
            <Route exact path="/myaccount" element={<ProtectedRoute><MyAccount /></ProtectedRoute>} />
            <Route exact path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route exact path="/search-result" element={<SearchResult/>} />
            <Route exact path="/reset-password-confirmation" element={<ResetPasswordConfirmation/>} />
          </Routes>
          <ToastContainer autoClose={5000}  />
        </BrowserRouter>
      </div>
  );
}
