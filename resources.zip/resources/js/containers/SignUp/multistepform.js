import StepWizard from "react-step-wizard";
import { useInjectReducer, useInjectSaga } from "redux-injectors";
import React, { Fragment, useState, useEffect, useRef } from "react";
import { ToastContainer, toast } from "react-toastify";
import { Formik, Form, Field, ErrorMessage } from "formik";
import { Button, Modal } from "react-bootstrap";
import * as Yup from "yup";
import validate from "./validate";
import { name, reducer, actions } from "./slice";
import { useDispatch, useSelector } from "react-redux";
import makeSelectSignup from "./selectors";
import Layout from "../Layout";
import saga from "./saga";
import { Link } from "react-router-dom";
import { DatePickerField, Phone } from "../../utils/HelperFormik";
import DropZoneEx from "../DropZoneEx";
import history from "../../utils/history";
import GoogleMap from "../SignUp/maps";
import { useDropzone } from "react-dropzone";

const year = new Date().getFullYear();
const maxDate = new Date(year - 5, 12, 31);
const minDate = new Date(year - 100, 1, 1);

const MultiStepForm = () => {
  // React Bootstrap Model
  const [showHide, setShowHide] = useState(true);

  const handleModalShowHide = () => {
    // this.setState({ showHide: !this.state.showHide })
    setShowHide(!showHide);
    history.push("/");
    setTimeout(() => location.reload(), 500);
  };

  const [state, updateState] = useState({
    form: {},
    demo: true, // uncomment to see more
  });

  const updateForm = (key, value) => {
    const { form } = state;

    form[key] = value;
    updateState({
      ...state,
      form,
    });
  };

  // Do something on step change
  const onStepChange = (stats) => {};

  const setInstance = (SW) =>
    updateState({
      ...state,
      SW,
    });

  const { SW, demo } = state;
  const refModal = useRef();
  return (
    <Layout>
      <div className="container">
        <Modal
          show={showHide}
          size="lg"
          aria-labelledby="contained-modal-title-vcenter"
          centered
          dialogClassName="modal-style1"
        >
          <Modal.Header
            closeButton
            onClick={handleModalShowHide}
          ></Modal.Header>
          <Modal.Body>
            <div className={"jumbotron"}>
              <div className="row">
                <div className="col-12 col-sm-12 rsw-wrapper">
                  <StepWizard
                    onStepChange={onStepChange}
                    isHashEnabled
                    transitions={state.transitions} // comment out for default transitions
                    instance={setInstance}
                  >
                    <First hashKey={"FirstStep"} update={updateForm} />
                    <Second form={state.form} />
                    <Third form={state.form} />
                    <Fourth form={state.form} />
                    {/* <Fifth form={state.form} /> */}
                    <Last hashKey={"TheEnd!"} />
                  </StepWizard>
                </div>
              </div>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    </Layout>
  );
};

export default MultiStepForm;

/**
 * Stats Component - to illustrate the possible functions
 * Could be used for nav buttons or overview
 */
const Stats = ({
  currentStep,
  firstStep,
  goToStep,
  lastStep,
  nextStep,
  previousStep,
  totalSteps,
  step,
}) => (
  <div className="mt-4">
    <div className="row">
        
      {step > 1 && (
        <div className="col-12 col-sm-6">
          <button className="btn btn-default btn-block w-100" onClick={previousStep}>
            Previous
          </button>
        </div>
      )}
      {step < totalSteps ? (
        <div className="col-12 col-sm-6">
          <button className="btn btn-primary btn-block w-100" onClick={nextStep}>
            Continue
          </button>
        </div>
      ) : (
        <div className="col-12 col-sm-6">
          <button className="btn btn-primary btn-block w-100" onClick={nextStep}>
            Finish
          </button>
        </div>
      )}
    </div>
  </div>
);

/** Steps */
const initialValues = {
  first_name: "",
  last_name: "",
  email: "",
  mobile_number: "",
  image_path: "",
  dob: "",
  gender: "",
  about: "",
};

const First = (props) => {
  const update = (e) => {
    props.update(e.target.name, e.target.value);
  };
  useInjectReducer({ key: name, reducer });
  useInjectSaga({ key: name, saga });

  const dispatch = useDispatch();
  const SignupState = useSelector(makeSelectSignup());
  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validate}
      onSubmit={(values) => {
        dispatch(actions.systemSignup(values));
      }}
    >
      {(formik) => {
        const {
          errors,
          touched,
          isValid,
          dirty,
          setFieldTouched,
          setFieldError,
        } = formik;
        return (
          <div className="clearfix">
            <div className="row justify-content-center">
              <div className="col-md-10 col-lg-8">
                  <h2 className="modal-heading text-center mb-5">Sign Up</h2>
                  <Form className="mt-4">
                    <div className="clearfix form-group">
                      <div className="row row-2">
                          <div className="col-12 col-sm-6 mb-2">
                              <label htmlFor="teacher" className="btn-radio w-100 btn-rdo-img mb-0">
                                  <Field
                                    type="radio"
                                    value="Teacher"
                                    name="roles"
                                    className="form-check-input"
                                    id="teacher"
                                  />
                                  <div className="btn-rdo-wrap d-flex justify-content-between align-items-center">
                                      <span className="text text-xl">Teacher</span>
                                      <div className="radio-img" style={{backgroundImage: `url('images/teacher.png')`}}></div>
                                  </div>
                              </label>
                          </div>
                          <div className="col-12 col-sm-6 mb-2">
                              <label htmlFor="student" className="btn-radio w-100 btn-rdo-img mb-0">
                                <Field
                                  type="radio"
                                  value="Student"
                                  name="roles"
                                  className="form-check-input"
                                  id="student"
                                />
                                  <div className="btn-rdo-wrap d-flex justify-content-between align-items-center">
                                      <span className="text text-xl">Student</span>
                                      <div className="radio-img" style={{backgroundImage: `url('images/graduated.png')`}}></div>
                                  </div>
                              </label>
                          </div>
                      </div>
                    </div>

                    <div className="form-group py-2">
                      {/* <label htmlFor="first_name">First Name</label> */}
                      <Field
                        type="text"
                        name="first_name"
                        id="first_name"
                        placeholder='First Name'
                        className={
                          errors.first_name && touched.first_name
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="first_name"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>

                    <div className="form-group py-2">
                      {/* <label htmlFor="last_name">Last Name</label> */}
                      <Field
                        type="text"
                        name="last_name"
                        id="last_name"
                        placeholder='Last Name'
                        className={
                          errors.last_name && touched.last_name
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="last_name"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>
                    <div className="form-group py-2">
                      {/* <label htmlFor="email">Email</label> */}
                      <Field
                        type="email"
                        name="email"
                        id="email"
                        placeholder='Email Address'
                        className={
                          errors.email && touched.email
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="email"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>

                    <div className="form-group py-2">
                      {/* <label htmlFor="password">Password</label> */}
                      <Field
                        type="password"
                        name="password"
                        id="password"
                        placeholder='Password'
                        className={
                          errors.password && touched.password
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="password"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>

                    <div className="form-group py-2">
                      {/* <label htmlFor="mobile_number">Mobile Number</label> */}
                      <Field
                        type="text"
                        name="mobile_number"
                        id="mobile_number"
                        placeholder="Mobile Number"
                        className={
                          errors.mobile_number && touched.mobile_number
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="mobile_number"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>

                    {/* <div className="form-group">
                                                                <label htmlFor="mobile_number">Phone Number</label>
                                                                <Phone name="mobile_number" onChange={handleChange} defaultCountry="AU"  className={
                                                                    errors.mobile_number && touched.mobile_number ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                                                                }/>
                                                        </div> */}
                    {/* <Stats step={1} {...props} className={!(dirty && isValid) ? "btn btn-primary btn-user btn-block disabled-btn" : "btn btn-primary btn-user btn-block"}
                                                            disabled={!(dirty && isValid)}/> */}
                    <div className="w-100 d-inline-block py-3">
                      <button
                        type="submit"
                        step={1}
                        className={
                          !(dirty && isValid)
                            ? "btn btn-primary btn-user btn-block disabled-btn w-100"
                            : "btn btn-primary btn-user btn-block w-100"
                        }
                        disabled={!(dirty && isValid)}
                      >
                        Sign Up
                      </button>
                    </div>
                    <div className="already-account text-center pt-3">Already have an account? <a to={"/"} className="color-primary">Sign In</a></div>
                    <div className="step-pagination text-center pt-5">
                      <span className="active"></span>
                      <span className=""></span>
                      <span className=""></span>
                      <span className=""></span>
                      <span className=""></span>
                    </div>
                  </Form>
              </div>
            </div>
          </div>
        );
      }}
    </Formik>
  );
};

const Second = (props) => {
  const update = (e) => {
    props.update(e.target.name, e.target.value);
  };
  useInjectReducer({ key: name, reducer });
  useInjectSaga({ key: name, saga });

  const dispatch = useDispatch();
  const SignupState = useSelector(makeSelectSignup());
  return (
    <Formik
      initialValues={{
        verification_code: "",
      }}
      onSubmit={(values) => {
        dispatch(
          actions.verifyUsers({
            ...values,
          })
        );
      }}
      validator={validate}
    >
      {(formik) => {
        const {
          errors,
          touched,
          isValid,
          dirty,
          values,
          setFieldValue,
          handleChange,
          setFieldTouched,
          setFieldError,
        } = formik;

        return (
          <div className="clearfix">
            <div className="row justify-content-center">
              <div className="col-md-10 col-lg-8">
                <h2 className="modal-heading text-center mb-4">Sign Up as a Teacher</h2>
                <h3 className="modal-subheading text-center mb-4">OTP Verification</h3>
                <Form className="clearfix">
                  <div className="sent-code-contact text-center pt-2 pb-4">
                    We Sent an OTP verification code to +91 9509523850
                  </div>
                  <div className="form-group mb-4">
                    <Field
                      type="text"
                      name="mobile_number"
                      id="mobile_number"
                      value={values.mobile_number}
                      placeholder="Phone number"
                      className={
                        errors.mobile_number && touched.mobile_number
                          ? "form-control form-control-user is-invalid"
                          : "form-control form-control-user"
                      }
                    />
                    <ErrorMessage
                      name="mobile_number"
                      component="span"
                      className="invalid-feedback"
                    />
                  </div>
                  <div className="form-group mb-4">
                    {/* <label htmlFor="email">
                      OTP
                      <span className={"text-danger"}>*</span>
                    </label> */}
                    <Field
                      type="number"
                      name="verification_code"
                      id="verification_code"
                      placeholder="Enter OTP here"
                      value={values.verification_code}
                      className={
                        errors.verification_code &&
                        touched.verification_code
                          ? "form-control form-control-user is-invalid"
                          : "form-control form-control-user"
                      }
                    />
                    <ErrorMessage
                      name="verification_code"
                      component="span"
                      className="invalid-feedback"
                    />
                  </div>
                  <div className="otp-countdown text-center">
                    You will receive OTP within <span className="color-primary text-center">03:58 min</span>
                  </div>
                  <div className="col-md-12 text-end mt-5">
                    {/* <Stats step={2} {...props} /> */}
                    <button
                      type="submit"
                      className={
                        !(dirty && isValid)
                          ? "btn btn-primary disabled-btn mx-1 w-100"
                          : "btn btn-primary mx-1 w-100"
                      }
                      disabled={!(dirty && isValid)}
                    >
                      Verify & Proceed
                    </button>
                  </div>
                  <div className="otp-not-get text-center pt-5 pb-3">
                    Didn't receive the OTP ?
                  </div>
                  <div className="text-center w-100 d-inline-block">
                    <button className="btn btn-outline-warning">Resend OTP</button>
                  </div>

                  <div className="step-pagination text-center pt-5">
                    <span className=""></span>
                    <span className="active"></span>
                    <span className=""></span>
                    <span className=""></span>
                    <span className=""></span>
                  </div>
                </Form>
              </div>
            </div>
          </div>
        );
      }}
    </Formik>
  );
};

const Third = (props) => {
  const update = (e) => {
    props.update(e.target.name, e.target.value);
  };
  useInjectReducer({ key: name, reducer });
  useInjectSaga({ key: name, saga });
  const [files, setFiles] = useState([]);
  const {getRootProps, getInputProps, isDragActive} = useDropzone({
    accept: "image/*",
    onDrop: acceptedFiles => {
      setFiles(
        acceptedFiles.map(file =>
          Object.assign(file, {
            preview: URL.createObjectURL(file)
          })
        )
      );
    }
  })
  const dispatch = useDispatch();
  const SignupState = useSelector(makeSelectSignup());
  
  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values) => {
        // const fd = new FormData();
        // fd.append("image_path", values.image_path);
        dispatch(actions.profilePage(values));
      }}
    >
      {(formik) => {
        const {
          errors,
          touched,
          isValid,
          dirty,
          setFieldTouched,
          setFieldError,
          setFieldValue,
        } = formik;
        return (
          <div className="clearfix">
            <div className="row justify-content-center">
              <div className="col-md-10 col-lg-8">
                <h2 className="modal-heading text-center mb-4">Sign Up as a Teacher</h2>
                <h3 className="modal-subheading text-center mb-4">Your Professional Profile Picture</h3>
                    <Form className="clearfox">
                        {/* <div className="form-group text-center">
                            <DropZoneEx />
                            <img src="images/guruu.png" style={{ height: "150px", width: "150px", borderRadius: "100%", border: "3px dashed #c2c2c2" }}/> 
                        </div>  */}
                        <div className="form-group pt-2">
                            {/* <label htmlFor="image_path">
                            Add Profile Picture (Max 5MB)
                            </label> */}
                            <DropZoneEx />
                            {/* <Field
                            type="file"
                            name="image_path"
                            id="image_path"
                            className={
                                errors.image_path && touched.image_path ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                            }
                            />
                            <ErrorMessage name="image_path" component="span" className="invalid-feedback" /> */}
                        </div>

                        <div className="form-group py-2">
                            <label htmlFor="dob">Date of birth</label>
                            <Field
                            type="date"
                            name="dob"
                            id="dob"
                            placeholder="How old are you?"
                            className={
                                errors.dob && touched.dob ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                            }
                            />
                            <ErrorMessage name="dob" component="span" className="invalid-feedback" />
                        </div>
                        <div className="form-group pt-2 pb-4">
                          <label htmlFor="gender">Select your Gender</label>
                          <div className="row row-2">
                              <div className="col-12 col-sm-6 mb-2">
                                <label htmlFor="male" className="btn-radio w-100 btn-rdo-img mb-0">
                                  <Field type="radio" id="male" name="gender" value="male" className="form-check-input"/>
                                  <div className="btn-rdo-wrap d-flex justify-content-between align-items-center">
                                    <span className="text">Male</span>
                                    <div className="radio-img" style={{backgroundImage: `url('images/graduated.png')`}}></div>
                                  </div>
                                </label>
                              </div>
                              <div className="col-12 col-sm-6 mb-2">
                                  <label htmlFor="female" className="btn-radio w-100 btn-rdo-img mb-0">
                                    <Field type="radio" id="female" name="gender" value="female" className="form-check-input"/>
                                    <div className="btn-rdo-wrap d-flex justify-content-between align-items-center">
                                      <span className="text">Female</span>
                                      <div className="radio-img" style={{backgroundImage: `url('images/teacher.png')`}}></div>
                                    </div>
                                  </label>
                              </div>
                          </div>
                        </div>
                        
                        <Stats step={3} {...props} />
                        {/* <Button
                            type="submit"
                            className={!(dirty && isValid) ? "btn btn-primary btn-user btn-block disabled-btn" : "btn btn-primary btn-user btn-block"}
                            disabled={!(dirty && isValid)}
                        >
                            Create Profile
                        </Button> */}

                    </Form>
                    <ToastContainer autoClose={5000}  />
                    
                    <div className="step-pagination text-center pt-5">
                      <span className=""></span>
                      <span className=""></span>
                      <span className="active"></span>
                      <span className=""></span>
                      <span className=""></span>
                    </div>
                </div>
            </div>
        </div>
        );
      }}
    </Formik>
  );
};

const Fourth = (props) => {
  const validate = () => {
    if (confirm("Are you sure you want to go back?")) {
      // eslint-disable-line
      props.previousStep();
    }
  };
  const update = (e) => {
    props.update(e.target.name, e.target.value);
  };
  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values) => {
        console.log(values);
        // dispatch(actions.profilePage(values));
      }}
    >
      {(formik) => {
        const {
          errors,
          touched,
          isValid,
          dirty,
          setFieldTouched,
          setFieldError,
          setFieldValue,
        } = formik;
        return (
          <div className="clearfix px-4">
            <div className="row justify-content-center">
              <div className="col-md-10 col-lg-12">
                <h2 className="modal-heading text-center mb-4">Sign Up as a Teacher</h2>
                <h3 className="modal-subheading text-center mb-4">Your Location</h3>
                <Form className="mt-5">
                  <div className="form-group">
                    {/* <label htmlFor="about">Enter Your Location</label> */}
                    <GoogleMap />
                    <Field type="hidden" />
                    <Field type="hidden" />
                    <ErrorMessage
                      name="about"
                      component="span"
                      className="invalid-feedback"
                    />
                  </div>

                  <div className="row justify-content-center">
                    <div className="col-md-12 col-lg-12">
                      <Stats step={4} {...props} previousStep={validate} />
                    </div>
                  </div>

                  <div className="step-pagination text-center pt-5">
                    <span className=""></span>
                    <span className=""></span>
                    <span className=""></span>
                    <span className="active"></span>
                    <span className=""></span>
                  </div>
                </Form>
              </div>
            </div>
          </div>
        );
      }}
    </Formik>
  );
};

const Last = (props) => {
  const validate = () => {
    if (confirm("Are you sure you want to go back?")) {
      // eslint-disable-line
      props.previousStep();
    }
  };
  const update = (e) => {
    props.update(e.target.name, e.target.value);
  };
  const submit = () => {
    toast.success('Registration completed successfully')
    history.push('/login');
    setTimeout(() => location.reload(), 1500);
      };
  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values) => {
        console.log(values);
        dispatch(actions.profilePage(values));
      }}
    >
      {(formik) => {
        const {
          errors,
          touched,
          isValid,
          dirty,
          setFieldTouched,
          setFieldError,
          setFieldValue,
        } = formik;
        return (
          <div className="clearfix px-4">
            <div className="row justify-content-center">
              <div className="col-md-10 col-lg-12">
                <h2 className="modal-heading text-center mb-4">Sign Up as a Teacher</h2>
                <h3 className="modal-subheading text-center mb-4">Choose one or more subjects you'd like to Teach</h3>
                <Form className="mt-5">
                  <div className="clearfix">
                    <h3 className="text-center mb-4"></h3>
                    <div className="icon-radio-group d-flex flex-wrap justify-content-between">
                      <div className="icon-radio">
                        <input
                          type="checkbox"
                          name="category"
                          id="category-dance"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="category-dance"
                        >
                          <div className="icon-txt">
                            <div className="selected-checkbox"><img src={'images/check.svg'} width="32px" /></div>
                            <span className="icon">
                              <svg width="650pt" height="650pt" version="1.1" viewBox="0 0 650 650">
                                <g>
                                  <path d="m499.83 510.66-37.645-20.41-104.7-177.32c-0.49219-3.0977-3.375-21.766-4.0195-39.895-0.050782-9.082 0.57031-18.699 2.4414-27.738l84.191 59.742c3.7422 8.7656 11.328 22.664 21.812 22.664 8.9219 0 25.289-7.1172 25.289-18.754 0-10.852-14.133-19.812-26.562-26.422-26.652-22.305-82.504-78.32-104.94-106.41 8.7188-0.37109 17.625-3.7734 25.531-11.57 6.0586-5.9766 10.359-12.023 12.84-18.02l12.188 9.2617c0.44141 0.33594 0.96484 0.5 1.4766 0.5 0.74609 0 1.4766-0.33594 1.9609-0.96875 0.81641-1.0742 0.60547-2.6133-0.46875-3.4336l-10.504-7.9844c4.8945-18.211-7.3242-31.207-7.9688-31.871-2.375-2.1602-8.2891-6.3906-15.406-8.5-8.5469-2.5352-15.676-1.0352-20.637 4.418l-10.191 11.906c-3.8086 4.0195-6.5625 7.5312-7.5 8.7578l-12.008 14.023-3.2461-2.9414c1.1992-8.8711 16.414-35.414 27.281-52.602 6.6758 1.2656 32.781 6.5781 51.238 15.328 2.4688 10.035 14.18 31.992 25.004 32 2.2305 0 4.2383-0.875 5.957-2.5859 5.6328-5.6406 8.5625-14.18 7.6367-22.293-0.70703-6.2344-3.9531-15.172-15.418-22.348-3.0508-1.9102-5.957-3.7031-8.793-5.4414-46.375-32.336-66.832-37.168-74.898-37.168-3.0352 0-4.4531 0.65625-4.9297 0.93359-0.074219 0.042968-0.14453 0.089844-0.21094 0.14062-39.902 29.848-61.91 67.367-74.039 104.54-0.91797 2.2969-1.7812 5.2422-2.3359 6.9961-20.402 64.746-10.938 127.56-9.4414 136.39-5.2461 9.25-50.23 89.176-50.23 108.7 0 19.348 65.742 79.109 80.953 92.676l-21.449 16.039c-0.84375 0.62891-1.1914 1.7344-0.85547 2.7266 0.33594 1.0078 1.2695 1.6875 2.3242 1.6875h36.148c6.0352 0 12.398-3.9883 16.211-10.148 4.4727-7.2305 4.7148-16.031 0.66016-24.148-0.039063-0.078126-0.11328-0.125-0.15625-0.20313-0.039063-0.0625-0.042969-0.13281-0.089844-0.19141l-57.754-75.352 42.75-61.227 137.5 170.35c0.015626 0.023437 0.039063 0.035156 0.054688 0.050781 0.17969 0.20312 0.38672 0.37109 0.61719 0.50781 0.078124 0.042969 0.15234 0.078125 0.23047 0.11328 0.20312 0.10156 0.41406 0.15234 0.63281 0.19141 0.054687 0.003906 0.10547 0.039062 0.16406 0.050781 0.066407 0.003906 0.12891 0.011719 0.20703 0.011719h62.188 0.050782c1.3477 0 2.4453-1.0977 2.4453-2.4531 0.007813-1.0586-0.65234-1.9531-1.582-2.3008zm-40.066-223.03c10.148 5.4922 22.535 13.363 22.535 21.332 0 8.0078-13.41 13.859-20.395 13.859-7.7109 0-14.359-13.027-16.957-18.883zm-45.707-200.5c2.207 1.3555 4.457 2.75 6.7969 4.2188 9.8125 6.1445 12.566 13.586 13.16 18.754 0.75781 6.668-1.6406 13.676-6.2422 18.277-0.78906 0.78906-1.5742 1.1602-2.4922 1.1602-6.7891 0-17.941-18.312-20.328-28.555zm-129.51 410.26 24.605-11.879c3.0352 7.918 0.50781 14.074-1.4062 17.168-2.8945 4.6758-7.7344 7.8164-12.047 7.8164h-28.785l17.477-13.07c0.050781-0.007813 0.10547-0.011719 0.15625-0.035156zm93.234-336.33c-10.203 10.059-28.777 16.465-47.578 1.418-5.9961-4.8047-7.5703-8.9531-7.2344-9.9414l17.445-20.379c0.039063-0.039062 0.089844-0.0625 0.125-0.10547 0.38672-0.47656 0.76172-0.92578 1.125-1.3594l0.78516-0.91797c6.5234-7.5273 10.02-8.7422 11.57-8.7422 3.3594 0 3.8789 7.2812 3.8867 7.3477 0.035156 0.81641 0.48047 1.5664 1.1875 1.9883 0.70703 0.42578 1.5742 0.46484 2.3125 0.10547 1.8359-0.87891 3.8477-1.3203 5.9688-1.3203 1.5508 0 3.1094 0.23438 4.6484 0.63281l17.961 13.648c-2.1055 5.7695-6.1875 11.691-12.203 17.625zm-73.746 148.96c-43.574-5.582-49.797-15.676-50.301-16.66-0.75781-4.207-11.68-68.441 9.1914-134.7 3.125-9.918 19.938-18.059 56.672-9.7266l-0.52734 0.61719c-0.078124 0.09375-0.15234 0.19141-0.21875 0.29688-2.4805 3.9766 0.77344 10.434 8.2891 16.453 5.7578 4.6133 12.801 7.9805 20.281 9.2852 13.383 25.297 4.6094 64.602 4.5117 65-6.8867 27.602-1.5977 61.059 0.24609 70.906-7.3984 0.35938-28.422 1.0547-48.145-1.4766zm139.18 200.48 17.551-15.469 28.516 15.469z"/>
                                </g>
                              </svg>
                            </span>
                            <span className="text">Dance</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="checkbox"
                          name="category"
                          id="category-fitness"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="category-fitness"
                        >
                          <div className="icon-txt">
                            <div className="selected-checkbox"><img src={'images/check.svg'} width="32px" /></div>
                            <span className="icon">
                              <svg width="700pt" height="700pt" version="1.1" viewBox="0 0 700 700" xmlns="http://www.w3.org/2000/svg">
                                <g>
                                  <path d="m124.61 261.18h15.609v87.117h41.309v49.816h76.195v-136.93h14.219v24.344c0 26.527 21.473 48.043 47.988 48.117v150.98c0 2.2148 1.7969 4.0078 4.0078 4.0078h52.141c2.2148 0 4.0156-1.793 4.0156-4.0078v-150.97c26.504-0.078126 47.988-21.594 47.988-48.117v-24.355h14.219v136.95h76.191v-49.816h41.309v-87.133h15.602c14.602 0.011719 26.434-11.832 26.434-26.426s-11.832-26.434-26.434-26.434h-15.602v-87.117h-41.309v-49.824l-76.203 0.003906v136.93h-14.219v-15.574c-0.023437-10.77-8.7461-19.5-19.516-19.5-10.777 0-19.516 8.7344-19.516 19.527 0-10.789-8.7344-19.527-19.523-19.527-10.777 0-19.512 8.7344-19.516 19.516 0-10.777-8.7422-19.516-19.516-19.516-10.781 0-19.523 8.7344-19.523 19.527 0-10.789-8.7305-19.527-19.512-19.527s-19.523 8.7344-19.523 19.527v15.543h-14.219v-136.93l-76.18 0.003906v49.824h-41.309v87.113l-15.609-0.003906c-14.602 0-26.434 11.836-26.434 26.434 0 14.594 11.832 26.43 26.434 26.441zm337.61-169.88h36.324v49.824h41.309v187.25h-41.309v49.824h-36.324zm-302.07 49.82h41.309v-49.824h36.336v286.89h-36.336v-49.824h-41.309z"/>
                                </g>
                              </svg>
                            </span>
                            <span className="text">Fitness</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="checkbox"
                          name="category"
                          id="category-academics"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="category-academics"
                        >
                          <div className="icon-txt">
                            <div className="selected-checkbox"><img src={'images/check.svg'} width="32px" /></div>
                            <span className="icon">
                              <svg width="700pt" height="700pt" version="1.1" viewBox="0 0 700 700" xmlns="http://www.w3.org/2000/svg">
                              <g>
                                <path d="m323.8 485.56c1.8242-2.5234 2.4414-5.7266 1.6836-8.75-0.80859-2.625-2.7539-4.7461-5.2969-5.7812-5.3164-2.4648-11.492-2.2344-16.613 0.61719-3.3633 1.875-6.0273 4.7891-7.5898 8.3047-2.75 5.9766-3.0156 12.801-0.74219 18.973 2.2734 6.1758 6.8984 11.199 12.867 13.969 7.957 3.6562 17.039 4.0078 25.258 0.97656 8.2148-3.0352 14.895-9.2031 18.57-17.152 4.8086-10.418 5.2812-22.324 1.3125-33.094-3.9648-10.773-12.047-19.527-22.465-24.34-12.406-5.7188-26.473-6.7148-39.562-2.8086-13.09 3.9102-24.305 12.457-31.543 24.043-2.2461 3.457-6.707 4.7148-10.43 2.9414-2-0.90625-3.5234-2.6211-4.1875-4.7109-0.66016-2.0938-0.40625-4.3711 0.71094-6.2656 9.4883-15.457 24.449-26.773 41.906-31.703l105.08-29.66h-0.003907c13.41-1.2109 26.902 1.1133 39.133 6.7422 14.727 6.8242 26.141 19.207 31.75 34.438 5.6055 15.227 4.9414 32.059-1.8477 46.801-3.7734 8.2305-9.8008 15.23-17.379 20.188l-109.13 30.824c-4.3594 1.2344-8.8711 1.8711-13.402 1.8867-7.0703-0.011719-14.055-1.5586-20.473-4.5352-9.8281-4.5547-17.449-12.816-21.195-22.98-3.75-10.164-3.3125-21.398 1.2109-31.242 3.8086-8.2617 10.746-14.672 19.281-17.816 8.5352-3.1484 17.973-2.7734 26.23 1.0391 6.8008 2.9727 11.93 8.8086 14.008 15.934 2.0195 7.5234 0.65625 15.555-3.7305 21.992zm272.68-47c6.6016-14.289 7.2539-30.617 1.8086-45.387-5.4414-14.77-16.531-26.77-30.824-33.359-15.418-7.1406-32.863-8.5898-49.25-4.0938-0.19922 0.039063-0.35938 0.12109-0.52344 0.16016-0.039063 0-103.23 29.141-103.23 29.141h0.003906c12.148-0.48438 24.242 1.9219 35.277 7.0234 14.742 6.7891 26.18 19.164 31.789 34.395 5.6094 15.23 4.9297 32.07-1.8867 46.801-4.1758 9.1445-11.129 16.742-19.867 21.711l105.44-29.742v0.003906c1.4844-0.40625 2.9453-0.88672 4.375-1.4453 11.91-4.5703 21.562-13.613 26.891-25.207zm-130.95-211.09s0 96.121 0.03125 96.332c0 21.836-51.742 39.539-115.57 39.539s-115.57-17.703-115.54-39.75l-0.003906-96.121c0-21.852 51.652-45.121 115.54-45.121 63.781 0 115.54 23.27 115.54 45.121zm-11.168 96.332c0-8.4766-35.508-28.34-104.37-28.34s-104.37 19.863-104.37 28.34c0 8.4766 35.508 28.34 104.37 28.34 68.855 0 104.37-19.863 104.37-28.34zm-333.62-157.07v104.88c-4.3516 2.0898-7.7734 5.7188-9.6055 10.184-1.8281 4.4688-1.9375 9.457-0.30078 14 1.6328 4.5391 4.8984 8.3125 9.1562 10.59l-18.078 67.32c0 8.6523 54.816 8.6523 54.816 0l-18.078-67.316 0.003906-0.003906c4.2578-2.2734 7.5195-6.0508 9.1562-10.59 1.6328-4.543 1.5273-9.5312-0.30469-14-1.832-4.4648-5.2539-8.0938-9.6055-10.184v-92.164c23.82 17.094 49.051 32.133 75.418 44.957 3.1914-49.176 70.285-71.211 136.7-71.211 66.473 0 133.45 22.035 136.59 71.281v-0.003906c40.59-19.938 78.531-44.855 112.96-74.18 1.8672-1.6953 2.7578-4.2188 2.3594-6.7109-0.39453-2.4922-2.0195-4.6172-4.3203-5.6523-37.352-10.016-152.05-44.203-239.97-107.4-4.5352-3.3867-10.754-3.3867-15.289 0-87.926 63.199-202.62 97.387-239.97 107.4-2.3008 1.0352-3.9258 3.1602-4.3203 5.6523s0.49219 5.0156 2.3594 6.7109c5.0898 4.3438 11.988 10.012 20.324 16.438z"/>
                              </g>
                              </svg>
                            </span>
                            <span className="text">Academics</span>
                          </div>
                        </label>
                      </div>
                    </div>
                    <div className="icon-radio-group d-flex flex-wrap justify-content-between">
                      <div className="icon-radio">
                        <input
                          type="checkbox"
                          name="category"
                          id="category-language"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="category-language"
                        >
                          <div className="icon-txt">
                            <div className="selected-checkbox"><img src={'images/check.svg'} width="32px" /></div>
                            <span className="icon">
                              <svg width="700pt" height="700pt" version="1.1" viewBox="0 0 700 700" xmlns="http://www.w3.org/2000/svg">
                                <g>
                                  <path d="m269.84 23.332c-9.9961 0-18.047 9.2305-18.047 20.691v62.434h178.37c5.8828 0 11.312 1.3281 16.203 3.5547l10.004-25.656h29.281l72.805 186.92h-26.867l-17.41-47.941h-42.633v126.03l70.523 80.848v-101.72h46.551c9.9961 0 18.047-9.2305 18.047-20.691v-263.78c0-11.461-8.0508-20.691-18.047-20.691zm201.11 85.949-6.4023 17c4.4531 7.1836 6.9961 15.617 6.9961 24.199v51.816h34.59z"/>
                                  <path d="m111.38 129.79c-9.9961 0-18.047 9.2305-18.047 20.691v263.78c0 11.461 8.0508 20.691 18.047 20.691h46.555v101.72l88.73-101.72h183.5c9.9961 0 18.047-9.2305 18.047-20.691v-263.78c0-11.461-8.0508-20.691-18.047-20.691zm132.16 59.906h4.3984c2.9297 0 6.7305 0.26562 11.418 0.82031 5.2695 0.55469 9.0742 0.84375 11.414 0.84375 0.58594 2.2188 0.003907 5.2773-1.7539 9.1602-1.1719 1.6641-1.7539 3.0391-1.7539 4.1484-1.1719 2.7734-2.0586 7.207-2.6445 13.309-0.58594 1.6641-0.86719 2.793-0.86719 3.3477 2.9297 0 6.1484-0.57812 9.6602-1.6875 14.641-1.6641 27.801-4.1445 39.512-7.4727v19.961c-15.812 3.8828-31.91 6.9414-48.309 9.1602h-4.3984c-0.58594 5.5469-1.168 12.195-1.7539 19.961 1.1719 0 2.9453-0.26562 5.2852-0.82031 9.9531-1.6641 17.258-2.7734 21.941-3.3281 0-0.55469 0.30469-1.6641 0.88672-3.3281v-4.9883c-0.58594-2.2188-0.003907-3.6133 1.7539-4.1719l21.078 3.3281 0.88672 2.5078c-0.58594 1.1094-1.4727 3.3242-2.6445 6.6523 14.055 1.1094 25.465 5.2734 34.25 12.488 13.469 12.758 20.211 26.605 20.211 41.586v5.832c-0.58594 19.973-11.996 36.609-34.246 49.926-8.7852 4.9922-15.832 7.4961-21.102 7.4961h-0.86719l-4.3984-4.1719c-6.4414-4.9922-11.41-8.582-14.926-10.801 14.641-2.2188 27.215-6.6719 37.758-13.328 10.539-8.875 16.117-19.137 16.703-30.785v-3.3281c-0.58594-12.758-6.7461-23.305-18.457-31.629-2.3438-1.6641-5.8438-3.0391-10.527-4.1484h-0.88672c-2.3438-1.1094-5.5625-1.9531-9.6602-2.5078-7.6133 20.527-20.191 41.043-37.758 61.57 1.7578 5.5469 3.7891 10.266 6.1289 14.152-2.9297 0.55469-7.0117 2.2148-12.281 4.9883-2.9297 0.55469-4.9805 1.1094-6.1523 1.6641-1.7578-1.1094-3.2266-3.0352-4.3984-5.8125-4.0977 2.7734-7.3203 4.6992-9.6602 5.8125-12.297 8.3203-23.125 12.488-32.492 12.488h-3.5078c-13.469-1.1094-20.797-10.527-21.965-28.277v-3.3281c0.58594-17.195 9.0781-33.57 25.477-49.105 7.6133-7.2109 18.441-13.859 32.492-19.961 0.58594-3.8828 0.88672-9.7109 0.88672-17.477 0.58594-4.9922 0.86719-7.207 0.86719-6.6523h-13.172c-6.4414 0.55469-11.41 0.82031-14.926 0.82031h-13.172c-0.58594 0-1.4727-0.26562-2.6445-0.82031l-3.5078-6.6758c-0.58594-1.6641-1.168-3.0391-1.7539-4.1484v-0.84375c-1.7578-3.3281-2.0586-5.8086-0.88672-7.4727h9.6602c4.0977 0.55469 7.0391 0.82031 8.7969 0.82031h13.172c8.7852 0 15.809-0.55469 21.078-1.6641 0-1.1094 0.28125-2.7695 0.86719-4.9922 1.1719-8.3203 1.7773-14.969 1.7773-19.961 0-3.3281-0.30469-6.3867-0.88672-9.1602zm38.645 83.215c-9.9531 1.6641-16.977 3.3242-21.078 4.9883-0.58594 0-1.4727 0.26562-2.6445 0.82031v19.141c0 9.9844 0.30469 14.992 0.88672 14.992 11.125-14.422 18.734-27.742 22.832-39.945zm-44.797 14.129c-14.055 7.7656-24.883 18.602-32.492 32.469-3.5117 4.4375-5.2656 9.9766-5.2656 16.633 0 7.7656 3.8047 11.645 11.418 11.645 7.0273 0 14.332-3.0352 21.941-9.1367 0.58594-0.55469 1.1914-1.1094 1.7773-1.6641 2.9297-3.3281 4.957-5.2773 6.1289-5.832l-0.86719-2.5078c-1.7578-13.312-2.6445-27.184-2.6445-41.609z"/>
                                </g>
                              </svg>
                            </span>
                            <span className="text">Languages</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="checkbox"
                          name="category"
                          id="category-skills"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="category-skills"
                        >
                          <div className="icon-txt">
                            <div className="selected-checkbox"><img src={'images/check.svg'} width="32px" /></div>
                            <span className="icon">
                              <svg width="700pt" height="700pt" version="1.1" viewBox="0 0 700 700" xmlns="http://www.w3.org/2000/svg">
                                <g>
                                  <path d="m522.01 281.34-28.422-42.633c-2.3086-3.5391-3.5898-7.6484-3.7109-11.871-1.6836-42.16-19.613-82.035-50.035-111.27s-70.98-45.562-113.17-45.566c-10.996 0.011719-21.969 1.0781-32.762 3.1875-42 8.5703-78.949 33.312-102.87 68.887-23.918 35.574-32.891 79.129-24.977 121.26 7.9141 42.129 32.078 79.461 67.277 103.93v76.066c0 12.379 4.9141 24.246 13.668 33 8.75 8.75 20.621 13.668 32.996 13.668h93.336c12.375 0 24.246-4.918 32.996-13.668 8.7539-8.7539 13.668-20.621 13.668-33 0-6.1875 2.4609-12.121 6.8359-16.496 4.375-4.3789 10.309-6.8359 16.5-6.8359 12.375 0 24.246-4.918 32.996-13.668 8.7539-8.7539 13.668-20.621 13.668-33v-32.246c0-4.332 1.207-8.582 3.4844-12.266 2.2812-3.6875 5.5391-6.6641 9.4141-8.6016l10.125-5.0625 0.003906-0.003906c5.9844-2.9922 10.398-8.4102 12.117-14.879 1.7148-6.4688 0.57422-13.363-3.1367-18.934zm-102.8-52.723-12.535 2.2109c0.027343 0.85156 0.25391 1.6484 0.25391 2.5039-0.03125 10.375-2.0469 20.645-5.9414 30.258l10.934 6.3164h-0.003906c4.5742 2.6406 6.8047 8.0234 5.4336 13.125-1.3672 5.1016-5.9961 8.6445-11.277 8.6367-2.0469 0-4.0547-0.53906-5.8242-1.5742l-11.129-6.4258h0.003907c-6.918 8.7578-15.559 16.004-25.387 21.285l4.4062 12.098c1.0664 2.9102 0.93359 6.1211-0.37109 8.9336-1.3086 2.8086-3.6797 4.9844-6.5898 6.043-2.9102 1.0586-6.125 0.91797-8.9336-0.39844-2.8047-1.3125-4.9727-3.6875-6.0234-6.6016l-4.2812-11.754h-0.003906c-11 2.3008-22.359 2.3008-33.359 0l-4.2812 11.754h-0.003907c-2.1992 6.0508-8.8945 9.1719-14.945 6.9727-6.0547-2.2031-9.1758-8.8945-6.9727-14.949l4.4062-12.098c-9.8281-5.2812-18.469-12.527-25.387-21.285l-11.129 6.4258c-1.7656 1.0312-3.7734 1.5742-5.8203 1.5742-5.2812 0.007812-9.9102-3.5352-11.277-8.6367-1.3711-5.1016 0.85938-10.484 5.4336-13.125l10.934-6.3164h-0.003906c-3.8945-9.6133-5.9102-19.883-5.9414-30.258 0-0.85547 0.22656-1.6523 0.25391-2.5039l-12.535-2.2109c-3.0508-0.53516-5.7617-2.2578-7.5391-4.793-1.7773-2.5352-2.4727-5.6758-1.9336-8.7227 0.53906-3.0508 2.2656-5.7578 4.8047-7.5312 2.5391-1.7734 5.6758-2.4648 8.7227-1.9219l12.676 2.2383c3.4727-10.613 9.0977-20.391 16.527-28.727l-8.2461-9.832h-0.003906c-4.1094-4.9453-3.4492-12.277 1.4766-16.406 4.9258-4.1289 12.262-3.5 16.41 1.4102l8.1914 9.7656c9.5078-5.8672 20.133-9.6992 31.195-11.254v-12.844c0-6.4414 5.2266-11.668 11.668-11.668 6.4453 0 11.668 5.2266 11.668 11.668v12.844c11.062 1.5547 21.688 5.3867 31.195 11.254l8.1914-9.7656c4.1484-4.9102 11.484-5.5391 16.41-1.4102s5.5859 11.461 1.4766 16.406l-8.2461 9.832c7.4258 8.3359 13.051 18.113 16.523 28.727l12.676-2.2383c3.0508-0.57813 6.2031 0.097656 8.75 1.8789 2.543 1.7812 4.2578 4.5117 4.7617 7.5781 0.53906 3.043-0.15625 6.1797-1.9297 8.7148-1.7734 2.5352-4.4805 4.2617-7.5273 4.7969z"/>
                                  <path d="m371.92 233.33c0 25.773-20.895 46.668-46.668 46.668-25.773 0-46.668-20.895-46.668-46.668 0-25.773 20.895-46.664 46.668-46.664 25.773 0 46.668 20.891 46.668 46.664"/>
                                </g>
                              </svg>
                            </span>
                            <span className="text">Soft Skills</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="checkbox"
                          name="category"
                          id="category-outdoor"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="category-outdoor"
                        >
                          <div className="icon-txt">
                            <div className="selected-checkbox"><img src={'images/check.svg'} width="32px" /></div>
                            <span className="icon">
                            <svg width="700pt" height="700pt" version="1.1" viewBox="100 0 500 500" xmlns="http://www.w3.org/2000/svg">
                              <g>
                                <path d="m530.32 353.36c-8.9609 0-13.441-3.9219-16.801-6.7188-6.7188-5.6016-13.441-5.6016-19.602 0-10.641 8.9609-23.52 8.9609-34.16 0-6.7188-5.6016-13.441-5.0391-19.602 0-10.641 8.9609-23.52 8.9609-34.16 0-6.7188-5.6016-13.441-5.6016-19.602 0-10.641 8.9609-23.52 8.9609-34.16 0-6.7188-5.6016-13.441-5.6016-19.602 0-10.641 8.9609-23.52 8.9609-34.16 0-6.7188-5.6016-13.441-5.6016-19.602 0-10.641 8.9609-23.52 8.9609-34.16 0-6.7188-5.6016-13.441-5.6016-19.602 0-10.641 8.9609-23.52 8.9609-34.16 0-6.7188-5.6016-13.441-5.6016-19.602 0-3.9219 2.8008-8.3984 6.7188-16.801 6.7188v-11.199c4.4805 0 6.7188-1.6797 10.078-4.4805 10.641-8.9609 23.52-8.9609 34.16 0 6.7188 5.6016 13.441 5.6016 19.602 0 10.641-8.9609 23.52-8.9609 34.16 0 6.7188 5.6016 13.441 5.6016 19.602 0 10.641-8.9609 23.52-8.9609 34.16 0 6.7188 5.6016 13.441 5.0391 19.602 0 10.641-8.9609 23.52-8.9609 34.16 0 6.7188 5.6016 13.441 5.6016 19.602 0 10.641-8.9609 23.52-8.9609 34.16 0 6.7188 5.6016 13.441 5.6016 19.602 0 10.641-8.9609 23.52-8.9609 34.16 0 6.7188 5.6016 13.441 5.6016 19.602 0 10.641-8.9609 23.52-8.9609 34.16 0 3.3594 2.8008 5.0391 4.4805 10.078 4.4805l0.007812 11.199z"/>
                                <path d="m224.56 279.44c19.602 2.8008 41.441 23.52 49.84 44.238 4.4805-2.2383 9.5195-3.3594 14.559-3.3594 7.8398 0 15.68 2.8008 22.398 8.3984 1.6797 1.1211 3.3594 2.2383 4.4805 2.2383 1.1211 0 2.8008-0.55859 4.4805-2.2383 6.7188-5.6016 14.559-8.3984 22.398-8.3984s15.68 2.8008 22.398 8.3984c1.6797 1.6797 3.3594 2.2383 4.4805 2.2383s2.8008-0.55859 4.4805-2.2383c6.7188-5.6016 14.559-8.3984 22.398-8.3984s15.68 2.8008 22.398 8.3984c1.6797 1.6797 3.3594 2.2383 4.4805 2.2383 1.1211 0 2.8008-0.55859 4.4805-2.2383 6.1602-5.0391 12.879-7.8398 19.602-8.3984l10.641-17.359v0.55859h19.602v-18.48h6.1602v-14h-66.074v12.32h-11.762v-20.16h61.602v-5.6016l-62.16 0.003906v-6.7188l62.16-0.003906-21.84-66.641-40.32 21.281v-6.7188l49.281-26.879-2.8008-5.0391-46.48 25.762v-9.5195l39.758-20.727s-12.879-5.0391-16.238-16.238c-2.2383-7.2812-5.6016-24.641-5.6016-24.641l-17.918 7.2812v-7.8398l21.84-8.9609-2.2383-5.0391-19.602 7.8398v-15.121h-6.1602v182.56h-51.52l-5.0391-11.762-19.602-1.1211v-7.2812l54.879 0.003906v-5.6016h-54.879v-5.6016l54.879 0.003906-20.16-46.48h-34.719v-6.7188h59.359v-5.6016h-59.359v-7.2812h55.441s-24.078-16.801-26.32-24.641c-3.3594-10.078-7.8398-33.039-7.8398-33.039l-21.84 8.9609v-7.2812l27.441-11.762-2.2383-5.0391-25.199 10.641v-24.078h-6.1602v11.199c-2.2383 22.961-19.602 123.2-131.6 147.84h-2.2383l-7.2812-0.55859-0.55859 5.6016 49.84 7.2812zm165.2 16.797c5.6016 0 10.078 5.0391 10.078 10.641 0 2.8008-1.1211 5.0391-3.3594 6.7188-2.2383 1.6797-4.4805 3.3594-7.2812 2.8008-5.6016 0-10.078-5.0391-10.078-10.641 0.55859-5.0391 5.0391-9.5195 10.641-9.5195zm-33.602 0c5.6016 0 10.078 5.0391 10.078 10.641 0 2.8008-1.1211 5.0391-3.3594 6.7188-2.2383 1.6797-4.4805 3.3594-7.2812 2.8008-5.6016 0-10.078-5.0391-10.078-10.641 0.55859-5.0391 5.6016-9.5195 10.641-9.5195zm-84.559-28-28-2.8008c43.68-15.68 63.84-44.238 72.801-70v75.039zm48.719 26.883c5.6016 0 10.078 5.0391 10.078 10.641 0 2.8008-1.1211 5.0391-3.3594 6.7188-2.2383 1.6797-4.4805 3.3594-7.2812 2.8008-5.6016 0-10.078-5.0391-10.078-10.641 0.55859-5.0391 5.0391-9.5195 10.641-9.5195zm-119.28-34.16c75.602-22.398 104.16-80.078 115.36-118.16-4.4805 33.602-24.078 98-110.32 118.72zm19.602 1.6797c61.602-19.602 86.238-62.16 95.762-95.762v4.4805c-4.4805 30.801-22.398 75.039-86.801 92.398z"/>
                              </g>
                            </svg>
                            </span>
                            <span className="text">Outdoor</span>
                          </div>
                        </label>
                      </div>
                    </div>
                    <div className="icon-radio-group d-flex flex-wrap justify-content-between">
                      <div className="icon-radio">
                        <input
                          type="checkbox"
                          name="category"
                          id="category-music"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="category-music"
                        >
                          <div className="icon-txt">
                            <div className="selected-checkbox"><img src={'images/check.svg'} width="32px" /></div>
                            <span className="icon">
                              <svg width="700pt" height="700pt" version="1.1" viewBox="0 -100 800 800" xmlns="http://www.w3.org/2000/svg">
                                <g>
                                    <path d="m533.23 287.75c-26.668-10.574-56.641-8.8594-81.93 4.6914-25.289 13.547-43.32 37.555-49.285 65.617-5.9688 28.062 0.73828 57.328 18.324 79.992 17.59 22.664 44.273 36.43 72.938 37.617 55.781 1.6836 101.97-40.676 101.97-95.746 0.39453-123.59 0-247.24 0-370.9 0-2.7461-0.44922-5.5469-0.73438-9.0234-3.0312 0.66797-5.3828 1.0938-7.6562 1.7383-107.96 30.984-215.47 62.191-323.49 92.781-9.8438 2.8008-9.625 8.3984-9.625 15.969l0.003906 267.95c-7.6562-2.9102-11.781-5.207-16.711-6.9453-39.168-13.562-74.211-5.9922-103.74 22.695-13.637 13.418-22.945 30.609-26.727 49.359-3.7812 18.754-1.8633 38.207 5.5078 55.859 11.551 28.23 35.648 49.426 65.117 57.285 29.473 7.8633 60.922 1.4805 85-17.246 24.078-18.723 38.008-47.637 37.645-78.133 0.48828-82.77 0.48828-165.53 0-248.28-0.054688-10.816 3.4141-15.016 13.551-17.816 52.949-14.34 105.66-29.695 158.44-44.844l76.137-21.875v165.48c-6.5625-2.6328-10.414-4.375-14.734-6.2227z"/>
                                </g>
                              </svg>
                            </span>
                            <span className="text">Music</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="checkbox"
                          name="category"
                          id="category-art"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="category-art"
                        >
                          <div className="icon-txt">
                            <div className="selected-checkbox"><img src={'images/check.svg'} width="32px" /></div>
                            <span className="icon">
                              <svg width="700pt" height="700pt" version="1.1" viewBox="0 0 700 700" xmlns="http://www.w3.org/2000/svg">
                                <g>
                                  <path d="m99.055 194.71c0 8.9414 4.4766 16.828 11.277 21.633l18.367 257.87c0.87891 12.434 11.32 22.164 23.785 22.164 12.453 0 22.906-9.7305 23.793-22.152l5.3164-74.664c36.914 74.73 115.04 124.93 198.51 124.93 0.49609 0 1-0.011719 1.4961-0.011719l2.5273-0.03125c15.961-0.28906 29.809-8.957 37.062-23.184 7.7266-15.199 6.3555-33.461-3.5898-47.66-14.941-21.309-20.566-47.422-15.84-73.527 7.0469-39.004 39.418-70.773 78.707-77.266 28.324-4.7148 56.02 2.7461 77.934 20.906 7.8203 6.4922 18.43 7.8125 27.703 3.4688 9.1211-4.2734 14.809-13.137 14.828-23.586 0-121.81-99.098-220.91-220.89-220.91-71.543 0-137.99 34.414-179.52 92.355-0.11328-0.10156-0.23828-0.19531-0.35547-0.29297 6.4023-14.695 9.9805-31.738 10.062-49.906 0.23828-49.836-24.414-89.078-56.141-89.336h-0.0625c-3.4883 0-6.5742 2.2891-7.5859 5.6328-6.4062 21.203-15.211 47.484-26.57 62.57-14.441 19.207-18.641 47.047-11.227 70.754-5.8047 4.8594-9.5898 12.078-9.5898 20.234zm94.52 0c0 5.8828-4.7891 10.668-10.668 10.668l-57.332 0.003906c-5.8789 0-10.668-4.7891-10.668-10.672 0-5.8828 4.7891-10.668 10.668-10.668h57.328c5.8828 0 10.672 4.7891 10.672 10.668zm-33.102 278.38c-0.30078 4.168-3.8086 7.4414-7.9883 7.4414s-7.6758-3.2617-7.9766-7.4297v-0.011718l-17.934-251.86h51.828zm219.57-374.55c113.06 0 205.05 91.988 205.05 205.48-0.011719 3.8477-2.1445 7.1523-5.707 8.8203-3.7148 1.7227-7.7695 1.2383-10.867-1.3203-25.145-20.832-58.215-29.695-90.625-24.352-45.793 7.5742-83.508 44.617-91.73 90.078-5.4805 30.316 1.0742 60.66 18.461 85.457 6.582 9.3906 7.5117 21.41 2.4453 31.367-4.6133 9.0508-13.074 14.344-23.289 14.527l-2.2383 0.03125c-0.46484 0-0.91797 0.011719-1.3828 0.011719-85.406 0-164.93-56.504-193.71-137.81-0.50781-1.4336-1.4648-2.5117-2.5703-3.3984l10.609-148.99c8.8008-4.3203 14.926-13.289 14.926-23.734 0-1.4414-0.20312-2.8281-0.42578-4.2109 38.168-57.574 102.1-91.953 171.05-91.953zm-247.5 14.707c11.648-15.477 20.223-38.992 27.105-61.105 19.492 5.293 34.906 36.465 34.73 72.621-0.074219 15.82-3.25 31.055-8.7422 43.707-0.91406-0.097656-1.8047-0.27734-2.7422-0.27734h-57.328c-0.76172 0-1.4805 0.16016-2.2266 0.22656-5.293-18.52-1.8359-40.512 9.2031-55.172z"/>
                                  <path d="m438.9 202.63c17.438 0 31.625-14.188 31.625-31.625 0-17.52-14.188-31.77-31.625-31.77-17.52 0-31.77 14.25-31.77 31.77 0 17.438 14.25 31.625 31.77 31.625zm0-47.547c8.6992 0 15.777 7.1406 15.777 15.922 0 8.6992-7.0781 15.777-15.777 15.777-8.7812 0-15.922-7.0781-15.922-15.777 0-8.7812 7.1406-15.922 15.922-15.922z"/>
                                  <path d="m341.17 202.63c17.438 0 31.625-14.188 31.625-31.625 0-17.52-14.188-31.77-31.625-31.77-17.52 0-31.77 14.25-31.77 31.77 0 17.438 14.25 31.625 31.77 31.625zm0-47.547c8.6992 0 15.777 7.1406 15.777 15.922 0 8.6992-7.0781 15.777-15.777 15.777-8.7812 0-15.922-7.0781-15.922-15.777 0-8.7812 7.1406-15.922 15.922-15.922z"/>
                                  <path d="m267.21 263.39c17.438 0 31.625-14.188 31.625-31.625 0-17.52-14.188-31.77-31.625-31.77-17.52 0-31.77 14.25-31.77 31.77-0.003906 17.438 14.246 31.625 31.77 31.625zm0-47.547c8.6992 0 15.777 7.1406 15.777 15.922 0 8.6992-7.0781 15.777-15.777 15.777-8.7812 0-15.922-7.0781-15.922-15.777 0-8.7812 7.1406-15.922 15.922-15.922z"/>
                                  <path d="m256.47 353.52c17.438 0 31.625-14.188 31.625-31.625 0-17.52-14.188-31.77-31.625-31.77-17.52 0-31.77 14.25-31.77 31.77 0 17.438 14.25 31.625 31.77 31.625zm0-47.547c8.6992 0 15.777 7.1406 15.777 15.922 0 8.6992-7.0781 15.777-15.777 15.777-8.7812 0-15.922-7.0781-15.922-15.777 0.003907-8.7812 7.1406-15.922 15.922-15.922z"/>
                                  <path d="m312.15 368.53c-23.504 0-42.637 19.121-42.637 42.625 0 23.391 19.129 42.418 42.637 42.418 23.391 0 42.418-19.027 42.418-42.418 0-23.504-19.027-42.625-42.418-42.625zm0 69.195c-14.766 0-26.785-11.918-26.785-26.57 0-14.766 12.02-26.777 26.785-26.777 14.652 0 26.57 12.012 26.57 26.777 0 14.652-11.918 26.57-26.57 26.57z"/>
                                </g>
                              </svg>
                            </span>
                            <span className="text">Art</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="checkbox"
                          name="category"
                          id="category-cooking"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="category-cooking"
                        >
                          <div className="icon-txt">
                            <div className="selected-checkbox"><img src={'images/check.svg'} width="32px" /></div>
                            <span className="icon">
                              <svg width="700pt" height="700pt" version="1.1" viewBox="0 0 700 700" xmlns="http://www.w3.org/2000/svg">
                                <path d="m233.36 371.77 0.070313 41.055h-95.797c-9.6758 0-17.5 7.8398-17.5 17.5v67.918c0 9.6602 7.8242 17.5 17.5 17.5h428.75c9.6758 0 17.5-7.8398 17.5-17.5v-67.918c0-9.6602-7.8242-17.5-17.5-17.5h-95.621l-0.085937-43.469c19.531-9.4688 38.586-22.664 54.637-41.039 0 0 37.328 18.516 64.262-13.613 9.2578-11.043 13.809-24.973 12.617-39.34-1.8203-21.926-16.555-39.727-36.398-46.461 0.57812-5.3008 1.418-10.289 1.6797-15.926 0 0 0.57813-17.168-17.484-18.27h-81.898l15.453-18.672 9.6758 7.4375s13.477 9.1172 24.535-3.2188l46.059-59.922c21.664-35.387-11.184-59.184-11.184-59.184-18.969-14.613-47.039-12.582-60.078 4.4102l-46.078 59.922c-2.8164 3.6758-4.0781 8.3281-3.4648 12.934 0.59375 4.6016 3.0117 8.7852 6.6836 11.621l6.0898 4.6719-33.129 40.023-268.67-0.007813c-9.2734 0-16.941 7.2461-17.465 16.504-0.050781 0.82422-0.31641 7.1406 0.42188 16.766-37.695 12.129-39.113 47.371-39.113 47.371-1.207 14.387 3.2734 28.352 12.602 39.359 0 0 23.102 30.746 65.539 12.984-0.007812-0.035156 20.957 27.895 57.395 44.062zm267.29-226.75-15.75-12.109 35.367-46.129s12.758-4.7422 16.414 11.305zm45.188 153.12c5.3359-10.113 9.8164-21.297 13.336-33.652 4.4453 3.1328 7.6641 7.9258 8.1367 13.738 0.40234 5.0586-1.1562 9.957-4.4258 13.824-0.003906 0-7.1445 8.5547-17.047 6.0898zm-236.93 6.1953-0.035156-74.656h104.53v49.488c-0.26172 7.9805-6.0195 8.1719-7.6484 8.2969-5.8281-0.28125-6.4766-5.8984-6.4062-8.0312 0 0-1.9414-36.348-35.629-40.844-14.438-1.9258-37.852 7.5781-41.598 40.617l-0.85938 25.34c-0.69922 2.957-2.3281 5.7227-6.1953 6.0898-5.668 0.52344-6.1562-6.3008-6.1562-6.3008zm-171.8-12.285c-3.2734-3.8672-4.8281-8.7656-4.4258-13.824 0.55859-6.7891 4.7266-12.215 10.359-15.102 2.9414 10.902 7.2617 22.699 13.352 34.633-12.793 3.1992-19.285-5.707-19.285-5.707zm227.22-11.883c0.035157 29.664 23.137 41.578 40.477 42.332 32.531-1.3125 43.906-26.773 43.594-43.262v-49.559h82.512c-17.344 129.85-152.74 128.94-175.14 128.52-66.746 2.3281-115.8-13.316-147.14-46.289-26.426-27.773-34.141-62.23-36.348-82.234h101.61l0.035156 77.996c0.89062 39.324 41.648 37.941 41.648 37.941 38.289-1.9062 40.637-38.484 40.637-38.484l1.0352-27.137s-0.14062-4.6367 3.6914-4.918c0 0 2.4336-0.75391 3.3945 5.0938zm-12.582 200.01c-8.7852 0-15.926-7.1211-15.926-15.891 0-8.7852 7.1406-15.926 15.926-15.926s15.926 7.1406 15.926 15.926c0 8.7656-7.1406 15.891-15.926 15.891zm28.262-87.52 0.050781 20.141h-55.949l-0.035156-20.074c0.003906 0.023437 23.875 2.6992 55.934-0.066407zm-111.63-8.2578c6.668 1.7656 13.578 3.2383 20.703 4.4609l0.035157 23.957h-20.684zm35.402 96.336h-148.64v-32.918h148.64c-6.5625 17.43 0 32.918 0 32.918zm95.918-32.918h149.19v32.918h-149.19c6.7734-17.465 0-32.918 0-32.918zm36.066-35h-20.719l-0.070313-25.023c6.668-1.3477 13.562-2.9922 20.738-5.0742zm-154.73-313.37c12.602 11.34 15.785 23.781 16.223 32.305 1.0859 21.789-14.121 38.727-16.012 40.426-14.086 12.496-24.746 0.61328-24.746 0.61328-6.9648-6.6328-7.2617-17.621-0.69922-24.641 1.8203-1.9961 8.3281-9.1719 6.4922-14.734-1.4531-4.4258-6.6484-9.8516-6.6484-9.8516-1.8555-2.0312-17.938-20.441-13.547-42.859 1.9609-10.012 8.7852-24.062 30.203-34.266 8.75-4.1836 19.164-0.4375 23.328 8.2773 4.1484 8.7344 0.17578 18.602-8.2969 23.328l-7.5938 4.7969c-0.015625-0.003906-8.6758 4.6523 1.2969 16.605zm98.438 0c12.602 11.34 15.785 23.781 16.223 32.305 1.0859 21.789-14.121 38.727-16.012 40.426-14.086 12.496-24.746 0.61328-24.746 0.61328-6.9648-6.6328-7.2617-17.621-0.69922-24.641 1.8203-1.9961 8.3281-9.1719 6.4922-14.734-1.4531-4.4258-6.6484-9.8516-6.6484-9.8516-1.8555-2.0312-17.938-20.441-13.547-42.859 1.9609-10.012 8.7852-24.062 30.203-34.266 8.75-4.1836 19.164-0.4375 23.328 8.2773 4.1484 8.7344 0.17578 18.602-8.2969 23.328l-7.5938 4.7969c-0.015625-0.003906-8.6758 4.6523 1.2969 16.605z"/>
                              </svg>
                            </span>
                            <span className="text">Cooking</span>
                          </div>
                        </label>
                      </div>
                    </div>

                    <div className="clearfix w-100 mt-4">
                      <Stats step={5} {...props} nextStep={submit}/>
                    </div>
                    
                    <div className="step-pagination text-center pt-5">
                      <span className=""></span>
                      <span className=""></span>
                      <span className=""></span>
                      <span className=""></span>
                      <span className="active"></span>
                    </div>
                  </div>
                  {/* <Button
                            type="submit"
                            className={!(dirty && isValid) ? "btn btn-primary btn-user btn-block disabled-btn" : "btn btn-primary btn-user btn-block"}
                            disabled={!(dirty && isValid)}
                        >
                            Create Profile
                        </Button> */}
                </Form>
              </div>
            </div>
          </div>
        );
      }}
    </Formik>
  );
};

// const Last = (props) => {
//   const submit = () => {
//     alert("You did it! Yay!"); // eslint-disable-line
//   };

//   return (
//     <div>
//       <div className={"text-center"}>
//         <h3>This is the last step in this example!</h3>
//         <hr />
//         {/* <Plugs /> */}
//       </div>
//       <Stats step={4} {...props} nextStep={submit} />
//     </div>
//   );
// };
