import { takeEvery, call, put } from 'redux-saga/effects';
import { actions } from './slice';
import * as api from './api';
import {toast} from 'react-toastify';
import LcStorage from "../../utils/LcStorage";
import history from "../../utils/history";

export function* systemSignup({ payload }) {
    try {
        yield call(api.getCookie);
        const response = yield call(api.signup, payload);
        if(response.status === 201) {
            yield put(actions.systemSignupSuccess(response.data.data));
            yield call(LcStorage.set, 'token', response.data.data.token, true)
            toast.success('User has been added successfully')
            history.push('/register#step2');
            setTimeout(() => location.reload(), 1000);
        }
    } catch (error) {
        if( error.response && error.response.status === 422 ) {
            yield put(actions.systemSignupFailure(error.response.data.errors));
        }else{
            toast.error('We are facing issues! Please try after some time')
        }
    }
}

export function* verifyUsers({ payload }) {
    try {
        const data = yield call(api.getOptUsers, payload);
        console.log("status", data.status);
        if(data.status === 200) {
            yield put(actions.systemSignupSuccess({ data: data.data }));
            toast.success('Mobile Number Verified successfully')
            history.push('/register#step3');
            setTimeout(() => location.reload(), 1000);
        }
        else{
            toast.error('Please Enter Correct OTP.')
        }
    } catch (error) {
        if(error.response && error.response.data){
            yield put(actions.systemSignupFailure(error.response.data.data));
        }else{
            toast.error('We are facing issues! Please try after some time')
        }
    }
}

export function* profilePage({ payload }) {
    try {
        const data = yield call(api.profilePage, payload);
        if(data.status === 200) {
            yield put(actions.systemSignupSuccess({ data: data.data }));
            toast.success('profile added successfully')
        }
        else{
            toast.error('Profile not saved successfully')
        }
    } catch (error) {
        if(error.response && error.response.data){
            yield put(actions.systemSignupFailure(error.response.data.data));
        }else{
            toast.error('We are facing issues! Please try after some time')
        }
    }
}

export function* loginOTP({ payload }) {
    try {
        yield call(api.getCookie);
        const response = yield call(api.loginOTP, payload);
        if(response.status === 200) {
            yield put(actions.systemSignupSuccess(response.data.data));
            yield call(LcStorage.set, 'token', response.data.data.token, true)
            history.push('/verify-login-otp');
            toast.success('Verification OTP sent to rgistered number')
            setTimeout(() => location.reload(), 1500);
        }
    } catch (error) {
        if( error.response && error.response.status === 422 ) {
            yield put(actions.systemSignupFailure(error.response.data.errors));
        }else{
            toast.error('We are facing issues! Please try after some time')
        }
    }
}

export function* getRoles({ payload }) {
    try {
        const data = yield call(api.getRoles, payload);
        yield put(actions.fetchSuccess({ data: data.data }));
    } catch (error) {
        yield put(actions.fetchFailure({ error }));
    }
}

// Individual exports for testing
export default function* hackerNewsArticlesSaga() {
    yield takeEvery(actions.systemSignup.type, systemSignup);
    yield takeEvery(actions.verifyUsers.type, verifyUsers);
    yield takeEvery(actions.loginOTP.type, loginOTP);
    yield takeEvery(actions.profilePage.type, profilePage);
    yield takeEvery(actions.fetch.type, getRoles);
}
