/*
 * HomePage
 *
 * This is the first thing users see of our App, at the '/' route
 *
 */

import React, {useEffect} from "react";
import { FormattedMessage } from "react-intl";
import { Formik, Form, Field, ErrorMessage } from "formik";
import { Link } from "react-router-dom";
import { shallowEqual, useSelector, useDispatch } from "react-redux";
import { name, reducer, actions } from "./slice";
import validate from "./validate";
import {useInjectReducer, useInjectSaga} from "redux-injectors";
import makeSelectSignup from "./selectors";
import Layout from "../Layout";
import saga from './saga'

export default function VerifyUser() {
    const dispatch = useDispatch();
    useInjectReducer({ key: name, reducer });
    useInjectSaga({ key: name, saga });

    return (
        <Layout>
            <Formik
                initialValues={{
                    mobile_number: "",
                    verification_code: ""
                }}
                onSubmit={(values) => {
                    dispatch(
                        actions.verifyUsers({
                            ...values,
                        })
                    );
                }}
                validator={validate}
            >
                {(formik) => {
                    const {
                        errors,
                        touched,
                        isValid,
                        dirty,
                        values,
                        setFieldValue,
                        handleChange,
                        setFieldTouched,
                        setFieldError,
                    } = formik;

                    return (
                        <div className="py-5 inner-pg">
                            <div className="container">
                                <div className="row justify-content-center">
                                    <div className="col-lg-12 col-xl-10">
                                        <div className="clearfix">
                                            <Form className="card">
                                                <div className="card-body">
                                                    <div className="row">

                                                        {/* <div className="form-group col-lg-6">
                                                            <label htmlFor="email">
                                                                Phone number
                                                                <span className={"text-danger"}>*</span>
                                                            </label>
                                                            <Field
                                                                type="text"
                                                                name="mobile_number"
                                                                id="mobile_number"
                                                                value={values.mobile_number}
                                                                className={
                                                                    errors.mobile_number && touched.mobile_number
                                                                        ? "form-control form-control-user is-invalid"
                                                                        : "form-control form-control-user"
                                                                }
                                                            />
                                                            <ErrorMessage
                                                                name="mobile_number"
                                                                component="span"
                                                                className="invalid-feedback"
                                                            />
                                                        </div> */}
                                                        <div className="form-group col-lg-6">
                                                            <label htmlFor="email">
                                                                OTP
                                                                <span className={"text-danger"}>*</span>
                                                            </label>
                                                            <Field
                                                                type="number"
                                                                name="verification_code"
                                                                id="verification_code"
                                                                value={values.verification_code}
                                                                className={
                                                                    errors.verification_code && touched.verification_code
                                                                        ? "form-control form-control-user is-invalid"
                                                                        : "form-control form-control-user"
                                                                }
                                                            />
                                                            <ErrorMessage
                                                                name="verification_code"
                                                                component="span"
                                                                className="invalid-feedback"
                                                            />
                                                        </div>
                                                        <div className="col-md-12 text-end mt-5">
                                                            <button
                                                                type="submit"
                                                                className={
                                                                    !(dirty && isValid)
                                                                        ? "btn btn-primary disabled-btn mx-1"
                                                                        : "btn btn-primary mx-1"
                                                                }
                                                                disabled={!(dirty && isValid)}
                                                            >
                                                                Verify Number
                                                            </button>
                                                            <Link
                                                                to="/"
                                                                className="btn btn-secondary mx-1"
                                                            >
                                                                Cancel
                                                            </Link>
                                                        </div>
                                                    </div>
                                                </div>
                                            </Form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                }}
            </Formik>
        </Layout>
    );
}
