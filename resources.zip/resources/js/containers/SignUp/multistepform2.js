import StepWizard from "react-step-wizard";
import { useInjectReducer, useInjectSaga } from "redux-injectors";
import React, { Fragment, useState, useEffect, useRef } from "react";
import { ToastContainer, toast } from "react-toastify";
import { Formik, Form, Field, ErrorMessage } from "formik";
import { Button, Modal } from "react-bootstrap";
import * as Yup from "yup";
import validate from "./validate";
import { name, reducer, actions } from "./slice";
import { useDispatch, useSelector } from "react-redux";
import makeSelectSignup from "./selectors";
import Layout from "../Layout";
import saga from "./saga";
import { Link } from "react-router-dom";
import { DatePickerField, Phone } from "../../utils/HelperFormik";
import DropZoneEx from "../DropZoneEx";
import history from "../../utils/history";
import GoogleMap from "../SignUp/maps";
import { useDropzone } from "react-dropzone";

const year = new Date().getFullYear();
const maxDate = new Date(year - 5, 12, 31);
const minDate = new Date(year - 100, 1, 1);

const MultiStepForm = () => {
  // React Bootstrap Model
  const [showHide, setShowHide] = useState(true);

  const handleModalShowHide = () => {
    // this.setState({ showHide: !this.state.showHide })
    setShowHide(!showHide);
    history.push("/");
    setTimeout(() => location.reload(), 500);
  };

  const [state, updateState] = useState({
    form: {},
    demo: true, // uncomment to see more
  });

  const updateForm = (key, value) => {
    const { form } = state;

    form[key] = value;
    updateState({
      ...state,
      form,
    });
  };

  // Do something on step change
  const onStepChange = (stats) => {};

  const setInstance = (SW) =>
    updateState({
      ...state,
      SW,
    });

  const { SW, demo } = state;
  const refModal = useRef();
  return (
    <Layout>
      <div className="container">
        <Modal
          show={showHide}
          size="lg"
          aria-labelledby="contained-modal-title-vcenter"
          centered
          dialogClassName="modal-style1"
        >
          <Modal.Header
            closeButton
            onClick={handleModalShowHide}
          ></Modal.Header>
          <Modal.Body>
            <h2 className="text-center mb-3">Sign Up</h2>
            <div className={"jumbotron"}>
              <div className="row">
                <div className="col-12 col-sm-12 rsw-wrapper">
                  <StepWizard
                    onStepChange={onStepChange}
                    isHashEnabled
                    transitions={state.transitions} // comment out for default transitions
                    instance={setInstance}
                  >
                    <First hashKey={"FirstStep"} update={updateForm} />
                    <Second form={state.form} />
                    <Third form={state.form} />
                    <Fourth form={state.form} />
                    {/* <Fifth form={state.form} /> */}
                    <Last hashKey={"TheEnd!"} />
                  </StepWizard>
                </div>
              </div>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    </Layout>
  );
};

export default MultiStepForm;

/**
 * Stats Component - to illustrate the possible functions
 * Could be used for nav buttons or overview
 */
const Stats = ({
  currentStep,
  firstStep,
  goToStep,
  lastStep,
  nextStep,
  previousStep,
  totalSteps,
  step,
}) => (
  <div className="mt-4">
    {step > 1 && (
      <button className="btn btn-default btn-block" onClick={previousStep}>
        Go Back
      </button>
    )}
    {step < totalSteps ? (
      <button className="btn btn-primary btn-block w-100" onClick={nextStep}>
        Continue
      </button>
    ) : (
      <button className="btn btn-success btn-block" onClick={nextStep}>
        Finish
      </button>
    )}
  </div>
);

/** Steps */
const initialValues = {
  first_name: "",
  last_name: "",
  email: "",
  mobile_number: "",
  image_path: "",
  dob: "",
  gender: "",
  about: "",
};

const First = (props) => {
  const update = (e) => {
    props.update(e.target.name, e.target.value);
  };
  useInjectReducer({ key: name, reducer });
  useInjectSaga({ key: name, saga });

  const dispatch = useDispatch();
  const SignupState = useSelector(makeSelectSignup());
  return (
    <Formik
      initialValues={initialValues}
      validationSchema={validate}
      onSubmit={(values) => {
        dispatch(actions.systemSignup(values));
      }}
    >
      {(formik) => {
        const {
          errors,
          touched,
          isValid,
          dirty,
          setFieldTouched,
          setFieldError,
        } = formik;
        return (
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-md-10 col-lg-8">
                  <Form className="mt-4">
                    <div className="clearfix form-group">
                      <label>Delivery Method</label>
                      <div className="row">
                          <div className="col-12 col-sm-6">
                              <label htmlFor="delivery_online" className="btn-radio w-100">
                                  <input type="radio" id="delivery_online" name="delivery_method"/>
                                  <div className="btn-rdo-wrap">
                                      <span className="text">Online</span>
                                  </div>
                              </label>
                          </div>
                          <div className="col-12 col-sm-6">
                              <label htmlFor="delivery_offline" className="btn-radio w-100">
                                  <input type="radio" id="delivery_offline" name="delivery_method"/>
                                  <div className="btn-rdo-wrap">
                                      <span className="text">Offline</span>
                                  </div>
                              </label>
                          </div>
                      </div>
                    </div>

                    <div className="form-group">
                      <div className="form-check form-check-inline m-2">
                        <label className="form-check-label">
                          <Field
                            type="radio"
                            value="Student"
                            name="roles"
                            className="form-check-input"
                          />
                          Student
                        </label>
                      </div>
                      <div className="form-check form-check-inline m-2">
                        <label className="form-check-label">
                          <Field
                            type="radio"
                            value="Teacher"
                            name="roles"
                            className="form-check-input"
                          />
                          Teacher
                        </label>
                      </div>
                    </div>
                    <div className="form-group">
                      {/* <label htmlFor="first_name">First Name</label> */}
                      <Field
                        type="text"
                        name="first_name"
                        id="first_name"
                        placeholder='First Name'
                        className={
                          errors.first_name && touched.first_name
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="first_name"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>

                    <div className="form-group">
                      {/* <label htmlFor="last_name">Last Name</label> */}
                      <Field
                        type="text"
                        name="last_name"
                        id="last_name"
                        placeholder='Last Name'
                        className={
                          errors.last_name && touched.last_name
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="last_name"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>
                    <div className="form-group">
                      {/* <label htmlFor="email">Email</label> */}
                      <Field
                        type="email"
                        name="email"
                        id="email"
                        placeholder='Email'
                        className={
                          errors.email && touched.email
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="email"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>

                    <div className="form-group">
                      {/* <label htmlFor="password">Password</label> */}
                      <Field
                        type="password"
                        name="password"
                        id="password"
                        placeholder='Password'
                        className={
                          errors.password && touched.password
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="password"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>

                    <div className="form-group">
                      {/* <label htmlFor="mobile_number">Mobile Number</label> */}
                      <Field
                        type="text"
                        name="mobile_number"
                        id="mobile_number"
                        placeholder="Mobile Number"
                        className={
                          errors.mobile_number && touched.mobile_number
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="mobile_number"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>

                    {/* <div className="form-group">
                                                                <label htmlFor="mobile_number">Phone Number</label>
                                                                <Phone name="mobile_number" onChange={handleChange} defaultCountry="AU"  className={
                                                                    errors.mobile_number && touched.mobile_number ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                                                                }/>
                                                        </div> */}
                    {/* <Stats step={1} {...props} className={!(dirty && isValid) ? "btn btn-primary btn-user btn-block disabled-btn" : "btn btn-primary btn-user btn-block"}
                                                            disabled={!(dirty && isValid)}/> */}
                    <button
                      type="submit"
                      step={1}
                      className={
                        !(dirty && isValid)
                          ? "btn btn-primary btn-user btn-block disabled-btn w-100"
                          : "btn btn-primary btn-user btn-block w-100"
                      }
                      disabled={!(dirty && isValid)}
                    >
                      Sign In
                    </button>
                  </Form>
              </div>
            </div>
          </div>
        );
      }}
    </Formik>
  );
};

const Second = (props) => {
  const update = (e) => {
    props.update(e.target.name, e.target.value);
  };
  useInjectReducer({ key: name, reducer });
  useInjectSaga({ key: name, saga });

  const dispatch = useDispatch();
  const SignupState = useSelector(makeSelectSignup());
  return (
    <Formik
      initialValues={{
        verification_code: "",
      }}
      onSubmit={(values) => {
        dispatch(
          actions.verifyUsers({
            ...values,
          })
        );
      }}
      validator={validate}
    >
      {(formik) => {
        const {
          errors,
          touched,
          isValid,
          dirty,
          values,
          setFieldValue,
          handleChange,
          setFieldTouched,
          setFieldError,
        } = formik;

        return (
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-md-10 col-lg-8">
                <Form className="clearfix">
                    <div className="form-group">
                      <label htmlFor="email">
                        Phone number
                        <span className={"text-danger"}>*</span>
                      </label>
                      <Field
                        type="text"
                        name="mobile_number"
                        id="mobile_number"
                        value={values.mobile_number}
                        className={
                          errors.mobile_number && touched.mobile_number
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="mobile_number"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>
                    <div className="form-group">
                      {/* <label htmlFor="email">
                        OTP
                        <span className={"text-danger"}>*</span>
                      </label> */}
                      <Field
                        type="number"
                        name="verification_code"
                        id="verification_code"
                        placeholder="Enter OTP here"
                        value={values.verification_code}
                        className={
                          errors.verification_code &&
                          touched.verification_code
                            ? "form-control form-control-user is-invalid"
                            : "form-control form-control-user"
                        }
                      />
                      <ErrorMessage
                        name="verification_code"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>
                    <div className="otp-countdown text-center">
                      You will receive OTP within <span className="color1">03:58 min</span>
                    </div>
                    <div className="col-md-12 text-end mt-5">
                      {/* <Stats step={2} {...props} /> */}
                      <button
                        type="submit"
                        className={
                          !(dirty && isValid)
                            ? "btn btn-primary disabled-btn mx-1 w-100"
                            : "btn btn-primary mx-1 w-100"
                        }
                        disabled={!(dirty && isValid)}
                      >
                        Verify & Proceed
                      </button>
                    </div>
                    <div className="otp-not-get text-center pt-5 pb-3">
                      Dont receive the OTP ?
                    </div>
                    <div className="text-center w-100 d-inline-block">
                      <button className="btn btn-outline-warning">Resend OTP</button>
                    </div>
                </Form>
              </div>
            </div>
          </div>
        );
      }}
    </Formik>
  );
};

const Third = (props) => {
  const update = (e) => {
    props.update(e.target.name, e.target.value);
  };
  useInjectReducer({ key: name, reducer });
  useInjectSaga({ key: name, saga });
  const [files, setFiles] = useState([]);
  const {getRootProps, getInputProps, isDragActive} = useDropzone({
    accept: "image/*",
    onDrop: acceptedFiles => {
      setFiles(
        acceptedFiles.map(file =>
          Object.assign(file, {
            preview: URL.createObjectURL(file)
          })
        )
      );
    }
  })
  const dispatch = useDispatch();
  const SignupState = useSelector(makeSelectSignup());
  
  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values) => {
        // const fd = new FormData();
        // fd.append("image_path", values.image_path);
        dispatch(actions.profilePage(values));
      }}
    >
      {(formik) => {
        const {
          errors,
          touched,
          isValid,
          dirty,
          setFieldTouched,
          setFieldError,
          setFieldValue,
        } = formik;
        return (
            <div className="container">
            <div className="row justify-content-center">
                <div className="col-lg-12 col-md-12">
                    <div className="text-center">
                        <h1 className="h4 text-gray-900 mb-4">Step 1 - Your Professional Profile Picture</h1>
                    </div>
                    <Form className="mt-4">
                        {/* <div className="form-group text-center">
                            <DropZoneEx />
                            <img src="images/guruu.png" style={{ height: "150px", width: "150px", borderRadius: "100%", border: "3px dashed #c2c2c2" }}/> 
                        </div>  */}
                        <div className="form-group">
                            <label htmlFor="image_path">
                            Add Profile Picture (Max 5MB)
                            </label>
                            <DropZoneEx />
                            {/* <Field
                            type="file"
                            name="image_path"
                            id="image_path"
                            className={
                                errors.image_path && touched.image_path ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                            }
                            />
                            <ErrorMessage name="image_path" component="span" className="invalid-feedback" /> */}
                        </div>

                        <div className="form-group">
                            <label htmlFor="dob">Date of birth</label>
                            <Field
                            type="date"
                            name="dob"
                            id="dob"
                            className={
                                errors.dob && touched.dob ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                            }
                            />
                            <ErrorMessage name="dob" component="span" className="invalid-feedback" />
                        </div>
                        <div className="form-group">
                            <label htmlFor="gender">Gender</label>
                            <div className="form-check form-check-inline m-2">
                                <label className="form-check-label">
                                    <Field type="radio" name="gender" value="male" className="form-check-input"/>
                                    Male
                                </label>
                            </div>
                            <div className="form-check form-check-inline m-2">
                                <label className="form-check-label">
                                    <Field type="radio" name="gender" value="female" className="form-check-input"/>
                                    Female
                                </label>
                            </div>    
                        </div>
                        
                        <Stats step={1} {...props} />
                        {/* <Button
                            type="submit"
                            className={!(dirty && isValid) ? "btn btn-primary btn-user btn-block disabled-btn" : "btn btn-primary btn-user btn-block"}
                            disabled={!(dirty && isValid)}
                        >
                            Create Profile
                        </Button> */}

                    </Form>
                    <ToastContainer autoClose={5000}  />
                </div>
            </div>
        </div>
        );
      }}
    </Formik>
  );
};

const Fourth = (props) => {
  const validate = () => {
    if (confirm("Are you sure you want to go back?")) {
      // eslint-disable-line
      props.previousStep();
    }
  };
  const update = (e) => {
    props.update(e.target.name, e.target.value);
  };
  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values) => {
        console.log(values);
        // dispatch(actions.profilePage(values));
      }}
    >
      {(formik) => {
        const {
          errors,
          touched,
          isValid,
          dirty,
          setFieldTouched,
          setFieldError,
          setFieldValue,
        } = formik;
        return (
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-md-12">
                <div className="p-5">
                  <Form className="mt-4">
                    <div className="form-group">
                      <label htmlFor="about">Enter Your Location</label>
                      <GoogleMap />
                      <Field type="hidden" />
                      <Field type="hidden" />
                      <ErrorMessage
                        name="about"
                        component="span"
                        className="invalid-feedback"
                      />
                    </div>

                    <Stats step={4} {...props} previousStep={validate} />
                    {/* <Button
                            type="submit"
                            className={!(dirty && isValid) ? "btn btn-primary btn-user btn-block disabled-btn" : "btn btn-primary btn-user btn-block"}
                            disabled={!(dirty && isValid)}
                        >
                            Create Profile
                        </Button> */}
                  </Form>
                </div>
              </div>
            </div>
          </div>
        );
      }}
    </Formik>
  );
};

const Last = (props) => {
  const validate = () => {
    if (confirm("Are you sure you want to go back?")) {
      // eslint-disable-line
      props.previousStep();
    }
  };
  const update = (e) => {
    props.update(e.target.name, e.target.value);
  };
  const submit = () => {
    toast.success('Registration completed successfully')
    history.push('/login');
    setTimeout(() => location.reload(), 1500);
      };
  return (
    <Formik
      initialValues={initialValues}
      onSubmit={(values) => {
        console.log(values);
        dispatch(actions.profilePage(values));
      }}
    >
      {(formik) => {
        const {
          errors,
          touched,
          isValid,
          dirty,
          setFieldTouched,
          setFieldError,
          setFieldValue,
        } = formik;
        return (
          <div className="container">
            <div className="row justify-content-center">
              <div className="col-lg-12 col-md-12">
                <Form className="mt-4">
                  <div className="clearfix">
                    <h3 className="text-center mb-4">Choose one or more subjects you would like to learn</h3>
                    <div className="icon-radio-group d-flex flex-wrap justify-content-between">
                      <div className="icon-radio">
                        <input
                          type="radio"
                          name="track-type"
                          id="track-type1"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="track-type1"
                        >
                          <div className="icon-txt">
                            <span className="icon">
                              <i className="bi bi-people"></i>
                            </span>
                            <span className="text">Dance</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="radio"
                          name="track-type"
                          id="track-type2"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="track-type2"
                        >
                          <div className="icon-txt">
                            <span className="icon">
                              <i className="bi bi-people"></i>
                            </span>
                            <span className="text">Fitness</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="radio"
                          name="track-type"
                          id="track-type3"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="track-type3"
                        >
                          <div className="icon-txt">
                            <span className="icon">
                              <i className="bi bi-people"></i>
                            </span>
                            <span className="text">Academics</span>
                          </div>
                        </label>
                      </div>
                    </div>
                    <div className="icon-radio-group d-flex flex-wrap justify-content-between">
                      <div className="icon-radio">
                        <input
                          type="radio"
                          name="track-type"
                          id="track-type1"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="track-type1"
                        >
                          <div className="icon-txt">
                            <span className="icon">
                              <i className="bi bi-people"></i>
                            </span>
                            <span className="text">Dance</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="radio"
                          name="track-type"
                          id="track-type2"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="track-type2"
                        >
                          <div className="icon-txt">
                            <span className="icon">
                              <i className="bi bi-people"></i>
                            </span>
                            <span className="text">Fitness</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="radio"
                          name="track-type"
                          id="track-type3"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="track-type3"
                        >
                          <div className="icon-txt">
                            <span className="icon">
                              <i className="bi bi-people"></i>
                            </span>
                            <span className="text">Academics</span>
                          </div>
                        </label>
                      </div>
                    </div>
                    <div className="icon-radio-group d-flex flex-wrap justify-content-between">
                      <div className="icon-radio">
                        <input
                          type="radio"
                          name="track-type"
                          id="track-type1"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="track-type1"
                        >
                          <div className="icon-txt">
                            <span className="icon">
                              <i className="bi bi-people"></i>
                            </span>
                            <span className="text">Dance</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="radio"
                          name="track-type"
                          id="track-type2"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="track-type2"
                        >
                          <div className="icon-txt">
                            <span className="icon">
                              <i className="bi bi-people"></i>
                            </span>
                            <span className="text">Fitness</span>
                          </div>
                        </label>
                      </div>

                      <div className="icon-radio">
                        <input
                          type="radio"
                          name="track-type"
                          id="track-type3"
                        />
                        <label
                          className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center"
                          htmlFor="track-type3"
                        >
                          <div className="icon-txt">
                            <span className="icon">
                              <i className="bi bi-people"></i>
                            </span>
                            <span className="text">Academics</span>
                          </div>
                        </label>
                      </div>
                    </div>
                    <Stats step={5} {...props} nextStep={submit}/>
                  </div>
                  {/* <Button
                            type="submit"
                            className={!(dirty && isValid) ? "btn btn-primary btn-user btn-block disabled-btn" : "btn btn-primary btn-user btn-block"}
                            disabled={!(dirty && isValid)}
                        >
                            Create Profile
                        </Button> */}
                </Form>
              </div>
            </div>
          </div>
        );
      }}
    </Formik>
  );
};

// const Last = (props) => {
//   const submit = () => {
//     alert("You did it! Yay!"); // eslint-disable-line
//   };

//   return (
//     <div>
//       <div className={"text-center"}>
//         <h3>This is the last step in this example!</h3>
//         <hr />
//         {/* <Plugs /> */}
//       </div>
//       <Stats step={4} {...props} nextStep={submit} />
//     </div>
//   );
// };
