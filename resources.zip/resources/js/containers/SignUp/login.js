import React, {useEffect} from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import {Button} from "reactstrap";
import validate from "./validate";
import { name, reducer, actions } from "./slice";
import {useInjectReducer, useInjectSaga} from "redux-injectors";
import {useDispatch, useSelector} from "react-redux";
import makeSelectSignup from "./selectors";
import Layout from "../Layout";
import saga from './saga'
import {Link} from "react-router-dom";


const initialValues = {
    
    mobile_number: ""
};

const Signup = () => {
    useInjectReducer({ key: name, reducer });
    useInjectSaga({ key: name, saga });

    const dispatch = useDispatch();
    const SignupState = useSelector(makeSelectSignup());

    return(
        <Layout>
        <Formik
            initialValues={initialValues}
            validationSchema={validate}
            onSubmit={(values) => {
                dispatch(actions.loginOTP(values))
            }}
        >
            {(formik) => {
                const { errors, touched, isValid, dirty, setFieldTouched, setFieldError } = formik;
                return (
                    <div className="container">
                        <div className="row justify-content-center">
                            <div className="col-xl-10 col-lg-12 col-md-12">
                                <div className="card o-hidden border-0 shadow-lg my-5">
                                    <div className="card-body p-0">
                                        <div className="row">
                                            <div className="col-lg-12">
                                                <div className="p-5">
                                                    <div className="text-center">
                                                        <h1 className="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                                    </div>
                                                    <Form className="mt-4">
                                                    
                                                        <div className="form-group">
                                                            <label htmlFor="mobile_number">Mobile Number</label>
                                                            <Field
                                                                type="text"
                                                                name="mobile_number"
                                                                id="mobile_number"
                                                                className={
                                                                    errors.mobile_number && touched.mobile_number ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                                                                }
                                                            />
                                                            <ErrorMessage
                                                                name="mobile_number"
                                                                component="span"
                                                                className="invalid-feedback"
                                                            />
                                                        </div>

                                                        {/* <div className="form-group">
                                                                <label htmlFor="mobile_number">Phone Number</label>
                                                                <Phone name="mobile_number" onChange={handleChange} defaultCountry="AU"  className={
                                                                    errors.mobile_number && touched.mobile_number ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                                                                }/>
                                                        </div> */}

                                                        <Button
                                                            type="submit"
                                                            className={!(dirty && isValid) ? "btn btn-primary btn-user btn-block disabled-btn" : "btn btn-primary btn-user btn-block"}
                                                            disabled={!(dirty && isValid)}
                                                        >
                                                            LogIn
                                                        </Button>

                                                    </Form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                );
            }}
        </Formik>
        </Layout>
    )
}

export default Signup;
