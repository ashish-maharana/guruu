import React, {useEffect} from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import {Button} from "reactstrap";
import validate from "./validate";
import { name, reducer, actions } from "./slice";
import {useInjectReducer, useInjectSaga} from "redux-injectors";
import {useDispatch, useSelector} from "react-redux";
import makeSelectSignup from "./selectors";
import Layout from "../Layout";
import saga from './saga'
import {Link} from "react-router-dom";
import {DatePickerField, Phone} from "../../utils/common/index"

const year = new Date().getFullYear();
const maxDate = new Date(year - 5, 12, 31);
const minDate = new Date(year - 100, 1, 1);

const initialValues = {
    image_path: null,
    dob : "",
    gender: ""
};

const ProfilePage = () => {
    useInjectReducer({ key: name, reducer });
    useInjectSaga({ key: name, saga });

    const dispatch = useDispatch();
    const SignupState = useSelector(makeSelectSignup());

    return(
        <Layout>
        <Formik
            initialValues={initialValues}
            onSubmit={(values) => {
                // const fd = new FormData();
                // fd.append("image_path", values.image_path);
                console.log(values);
                dispatch(actions.profilePage(values))
            }}
        >
            {(formik) => {
                const { errors, touched, isValid, dirty, setFieldTouched, setFieldError, setFieldValue } = formik;
                return (
                    <div className="container">
                        <div className="row justify-content-center">
                            <div className="col-xl-10 col-lg-12 col-md-12">
                                <div className="card o-hidden border-0 shadow-lg my-5">
                                    <div className="card-body p-0">
                                        <div className="row">
                                            <div className="col-lg-12">
                                                <div className="p-5">
                                                    <div className="text-center">
                                                        <h1 className="h4 text-gray-900 mb-4">Your Professional Profile Picture</h1>
                                                    </div>
                                                    <Form className="mt-4">
                                                        <div className="form-group col-md-6">
                                                            <label htmlFor="image_path">
                                                            Add Profile Picture (Max 5MB)
                                                            </label>
                                                            <input
                                                            id="image_path"
                                                            name="image_path"
                                                            type="file"
                                                            accept="image/*"
                                                            onChange={(event) => {
                                                                setFieldTouched("image_path", true);
                                                                setFieldValue(
                                                                "image_path",
                                                                event.currentTarget.files[0],
                                                                true
                                                                );
                                                            }}
                                                            className={
                                                                errors.image_path &&
                                                                touched.image_path
                                                                ? "form-control logo-file-upload is-invalid"
                                                                : "form-control logo-file-upload"
                                                            }
                                                            />

                                                            {errors.image_path &&
                                                            touched.image_path && (
                                                                <span className="invalid-feedback">
                                                                {errors.image_path}
                                                                </span>
                                                            )}
                                                        </div>

                                                        <div className="form-group">
                                                                <label htmlFor="dob">Date of birth</label>
                                                                <DatePickerField
                                                                    dateFormat="MMMM d, yyyy"
                                                                    className="form-control"
                                                                    name="dob"
                                                                    maxDate={maxDate}
                                                                    minDate={minDate}
                                                                    showYearDropdown
                                                                    scrollableYearDropdown
                                                                    yearDropdownItemNumber={15}
                                                                />
                                                                <ErrorMessage
                                                                    name="dob"
                                                                    component="span"
                                                                    className="invalid-feedback"
                                                                />
                                                            </div>
                                                            <div className="form-group">
                                                            <label htmlFor="dob">Gender</label>
                                                            <div className="form-check form-check-inline m-2">
                                                                        <label className="form-check-label">
                                                                            <Field type="radio" name="gender" value="male" className="form-check-input"/>
                                                                            Male
                                                                        </label>
                                                                    </div>
                                                                    <div className="form-check form-check-inline m-2">
                                                                        <label className="form-check-label">
                                                                            <Field type="radio" name="gender" value="female" className="form-check-input"/>
                                                                            Female
                                                                        </label>
                                                                    </div>    
                                                            </div>

                                                        {/* <div className="form-group">
                                                                <label htmlFor="mobile_number">Phone Number</label>
                                                                <Phone name="mobile_number" onChange={handleChange} defaultCountry="AU"  className={
                                                                    errors.mobile_number && touched.mobile_number ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                                                                }/>
                                                        </div> */}

                                                        <Button
                                                            type="submit"
                                                            className={!(dirty && isValid) ? "btn btn-primary btn-user btn-block disabled-btn" : "btn btn-primary btn-user btn-block"}
                                                            disabled={!(dirty && isValid)}
                                                        >
                                                            Sign In
                                                        </Button>

                                                    </Form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                );
            }}
        </Formik>
        </Layout>
    )
}

export default ProfilePage;
