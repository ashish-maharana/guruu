import React, {useEffect} from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import {Button} from "reactstrap";
import validate from "./validate";
import { name, reducer, actions } from "./slice";
import {useInjectReducer, useInjectSaga} from "redux-injectors";
import {useDispatch, useSelector} from "react-redux";
import makeSelectSignup from "./selectors";
import Layout from "../Layout";
import saga from './saga'
import {Link} from "react-router-dom";


const initialValues = {
    first_name : "",
    last_name : "",
    email: "",
    mobile_number: ""
};

const Signup = () => {
    useInjectReducer({ key: name, reducer });
    useInjectSaga({ key: name, saga });

    const dispatch = useDispatch();
    const SignupState = useSelector(makeSelectSignup());

    return(
        <Layout>
        <Formik
            initialValues={initialValues}
            validationSchema={validate}
            onSubmit={(values) => {
                dispatch(actions.systemSignup(values))
            }}
        >
            {(formik) => {
                const { errors, touched, isValid, dirty, setFieldTouched, setFieldError } = formik;
                return (
                    <div className="container">
                        <div className="row justify-content-center">
                            <div className="col-xl-10 col-lg-12 col-md-12">
                                <div className="card o-hidden border-0 shadow-lg my-5">
                                    <div className="card-body p-0">
                                        <div className="row">
                                            <div className="col-lg-12">
                                                <div className="p-5">
                                                    <div className="text-center">
                                                        <h1 className="h4 text-gray-900 mb-4">Welcome Back!</h1>
                                                    </div>
                                                    <Form className="mt-4">
                                                    <div className="form-group">
                                                            <label htmlFor="first_name">First Name</label>
                                                            <Field
                                                                type="text"
                                                                name="first_name"
                                                                id="first_name"
                                                                className={
                                                                    errors.first_name && touched.first_name ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                                                                }
                                                            />
                                                            <ErrorMessage name="first_name" component="span" className="invalid-feedback" />
                                                        </div>

                                                        <div className="form-group">
                                                            <label htmlFor="last_name">Last Name</label>
                                                            <Field
                                                                type="text"
                                                                name="last_name"
                                                                id="last_name"
                                                                className={
                                                                    errors.last_name && touched.last_name ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                                                                }
                                                            />
                                                            <ErrorMessage name="last_name" component="span" className="invalid-feedback" />
                                                        </div>
                                                        <div className="form-group">
                                                            <label htmlFor="email">Email</label>
                                                            <Field
                                                                type="email"
                                                                name="email"
                                                                id="email"
                                                                className={
                                                                    errors.email && touched.email ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                                                                }
                                                            />
                                                            <ErrorMessage name="email" component="span" className="invalid-feedback" />
                                                        </div>

                                                        <div className="form-group">
                                                            <label htmlFor="password">Password</label>
                                                            <Field
                                                                type="password"
                                                                name="password"
                                                                id="password"
                                                                className={
                                                                    errors.password && touched.password ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                                                                }
                                                            />
                                                            <ErrorMessage
                                                                name="password"
                                                                component="span"
                                                                className="invalid-feedback"
                                                            />
                                                        </div>

                                                        <div className="form-group">
                                                            <label htmlFor="mobile_number">Mobile Number</label>
                                                            <Field
                                                                type="text"
                                                                name="mobile_number"
                                                                id="mobile_number"
                                                                className={
                                                                    errors.mobile_number && touched.mobile_number ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                                                                }
                                                            />
                                                            <ErrorMessage
                                                                name="mobile_number"
                                                                component="span"
                                                                className="invalid-feedback"
                                                            />
                                                        </div>

                                                        {/* <div className="form-group">
                                                                <label htmlFor="mobile_number">Phone Number</label>
                                                                <Phone name="mobile_number" onChange={handleChange} defaultCountry="AU"  className={
                                                                    errors.mobile_number && touched.mobile_number ? "form-control form-control-user is-invalid" : "form-control form-control-user"
                                                                }/>
                                                        </div> */}

                                                        <button
                                                            type="submit"
                                                            className={!(dirty && isValid) ? "btn btn-primary btn-user btn-block disabled-btn" : "btn btn-primary btn-user btn-block"}
                                                            disabled={!(dirty && isValid)}
                                                        >
                                                            Sign In
                                                        </button>

                                                    </Form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                );
            }}
        </Formik>
        </Layout>
    )
}

export default Signup;
