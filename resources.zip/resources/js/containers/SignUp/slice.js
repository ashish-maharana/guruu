import { createSlice } from '@reduxjs/toolkit';
import {DEFAULT_LOCALE} from "../../locales";

export const initialState = {
    first_name : "",
    last_name : "",
    email: "",
    password:"",
    mobile_number: "",
    image_path: null,
    dob : "",
    gender: "",
    errors:'',
    user:'',
    token:null,
    loading: false,
    data : []
};

const signupSlice = createSlice({
    name: 'signup',
    initialState,
    reducers: {
        systemSignup(){},
        systemSignupSuccess(state, action) {
            state.user = action.payload.user;
            state.token = action.payload.token;
        },
        systemSignupFailure(state, action) {
            state.errors = action.payload;
        },
        verifyUsers() {},
        profilePage() {
            console.log("Hi from profile slice");
        },
        loginOTP() {},
        fetch(state) {
            state.loading = true;
            state.error = false;
            state.data = [];
        },
        fetchSuccess(state, action) {
            state.data = action.payload.data;
            state.loading = false;
        },
        
    },
});

export const { name, actions, reducer } = signupSlice;
