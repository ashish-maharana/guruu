import request from './../../utils/request';
import {BASE_URL} from "../../utils/constants";
import Cookie from "js-cookie";


export const getCookie = async() => {
    return await request.get("/sanctum/csrf-cookie");
}

export const signup = async(data) => {
    const requestURL = `api/register`;
    return await request.post(requestURL, data);
}

export const getOptUsers = async (payload) => {
    const getOptUsers = `/api/verify-mobile-number`;
    return await request.post(getOptUsers, payload);
};

export const profilePage = async (payload) => {
    const profilePage = `/api/profile-page`;
    return await request.post(profilePage, payload);
};

export const loginOTP = async(data) => {
    const loginOTP = `api/login-with-otp`;
    return await request.post(loginOTP, data);
}

export const getRoles = async () => {
    const getRoles = `/api/roles`;
    return await request.get(getRoles);
};