import React, { Fragment, useState, useEffect } from 'react';

import StepWizard from "react-step-wizard";

/**
 * A basic demonstration of how to use the step wizard
 */
const Track= () => {
    const [state, updateState] = useState({
        form: {},
        demo: true, // uncomment to see more
    });

    const updateForm = (key, value) => {
        const { form } = state;

        form[key] = value;
        updateState({
            ...state,
            form,
        });
    };

    // Do something on step change
    const onStepChange = (stats) => {
        // console.log(stats);
    };

    const setInstance = SW => updateState({
        ...state,
        SW,
    });

    const { SW, demo } = state;

    return (
        <div className='container'>
            <div className={'jumbotron'}>
                <div className='row'>
                    <div className="col-12 col-sm-12 rsw-wrapper">
                        <StepWizard
                            onStepChange={onStepChange}
                            isHashEnabled
                            transitions={state.transitions} // comment out for default transitions
                            instance={setInstance}
                        >
                            <First hashKey={'FirstStep'} update={updateForm} />
                            <Second form={state.form} />
                            <Third form={state.form} />
                            {null /* will be ignored */}
                            <Last hashKey={'TheEnd!'} />
                        </StepWizard>
                    </div>
                </div>
            </div>
            {/* { (demo && SW) && <InstanceDemo SW={SW} /> } */}
        </div>
    );
};

export default Track;

/** Demo of using instance */
// const InstanceDemo = ({ SW }) => (
//     <Fragment>
//         <h4>Control from outside component</h4>
//         <button className={'btn btn-secondary'} onClick={SW.previousStep}>Previous Step</button>
//         &nbsp;
//         <button className={'btn btn-secondary'} onClick={SW.nextStep}>Next Step</button>
//         &nbsp;
//         {/* <button className={'btn btn-secondary'} onClick={() => SW.goToNamedStep('progress')}>Go to 'progress'</button> */}
//     </Fragment>
// );

/**
 * Stats Component - to illustrate the possible functions
 * Could be used for nav buttons or overview
 */
const Stats = ({
    currentStep,
    firstStep,
    goToStep,
    lastStep,
    nextStep,
    previousStep,
    totalSteps,
    step,
}) => (
    <div className="mt-4">
        <div className="row justify-content-center">
            { step > 1 &&
                <div className="col-12 col-sm-6">
                    <button className='btn btn-default btn-block w-100' onClick={previousStep}>Previous</button>
                </div>
            }
            { step < totalSteps ?
                <div className="col-12 col-sm-6">
                    <button className='btn btn-primary btn-block w-100' onClick={nextStep}>Next</button>
                </div>
                :
                <div className="col-12 col-sm-6">
                    <button className='btn btn-primary btn-block w-100' onClick={nextStep}>Done</button>
                </div>
            }
        </div>

        {/* <div style={{ fontSize: '21px', fontWeight: '200' }}>
            <div>Current Step: {currentStep}</div>
            <div>Total Steps: {totalSteps}</div>
            <button className='btn btn-block btn-default' onClick={firstStep}>First Step</button>
            <button className='btn btn-block btn-default' onClick={lastStep}>Last Step</button>
            <button className='btn btn-block btn-default' onClick={() => goToStep(2)}>Go to Step 2</button>
        </div> */}
    </div>
);

/** Steps */

const First = props => {
    const update = (e) => {
        props.update(e.target.name, e.target.value);
    };

    return (
        <div className="clearfix">
            <h3 className='modal-subheading text-center mb-5'>Select a Class Type</h3>
            <div className="form-group">
                <label>First Name</label>
                <input type='text' className='form-control' name='firstname' placeholder='First Name'
                    onChange={update} />
            </div>

            <div className="icon-radio-group d-flex flex-wrap justify-content-between py-3">
                <div className="icon-radio">
                    <input type="radio" name="track-type" id="track-type1"/>
                    <label className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center" htmlFor="track-type1">
                        <div className="icon-txt">
                            <span className="icon"><i className="bi bi-people"></i></span>
                            <span className="text">Class</span>
                        </div>
                    </label>
                </div>
                
                <div className="icon-radio">
                    <input type="radio" name="track-type" id="track-type2"/>
                    <label className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center" htmlFor="track-type2">
                        <div className="icon-txt">
                            <span className="icon"><i className="bi bi-people"></i></span>
                            <span className="text">Workplace</span>
                        </div>
                    </label>
                </div>
                
                <div className="icon-radio">
                    <input type="radio" name="track-type" id="track-type3"/>
                    <label className="radio-icon-box d-flex flex-wrap align-items-center justify-content-center" htmlFor="track-type3">
                        <div className="icon-txt">
                            <span className="icon"><i className="bi bi-people"></i></span>
                            <span className="text">Conference</span>
                        </div>
                    </label>
                </div>
            </div>
            <div className="row justify-content-center">
                <div className="col-sm-12">
                    <Stats step={1} {...props} />
                </div>
            </div>
        </div>
    );
};

const Second = props => {
    const validate = () => {
        if (confirm('Are you sure you want to go back?')) { // eslint-disable-line
            props.previousStep();
        }
    };

    return (
        <div>
            {/* { props.form.firstname && <h3>Hey {props.form.firstname}!</h3> } */}
            <div className="clearfix">
                <h3 className='modal-subheading text-center mb-5'>How frequently do you want to take classes?</h3>
                <div className="row modal-two-column-form">
                    <div className="col-12 col-md-6">
                        <div className="row">
                            <div className="col-12 col-md-6 form-group">
                                <label>Frequency of Track</label>
                                <select className="form-control">
                                    <option>Daily</option>
                                    <option>Weekly</option>
                                    <option>Monthly</option>
                                </select>
                            </div>
                            <div className="col-12 col-md-6 form-group">
                                <label>Select Duration</label>
                                <select className="form-control">
                                    <option>60 Minutes</option>
                                    <option>120 Minutes</option>
                                    <option>180 Minutes</option>
                                </select>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="square-radio">
                                <input type="radio" className=""/>
                                <span className="text">Skip Weekends</span>
                            </div>
                        </div>

                        <div className="row pt-3">
                            <div className="col-12 col-md-6 form-group">
                                <label>Starting From</label>
                                <div className="field-icon">
                                    <i className="bi bi-calendar"></i>
                                    <input type="text" className="form-control" />
                                </div>
                            </div>
                            
                            <div className="col-12 col-md-6 form-group">
                                <label>Ending From</label>
                                <div className="field-icon">
                                    <i className="bi bi-calendar"></i>
                                    <input type="text" className="form-control" placeholder="Enter Date or Time" />
                                </div>
                            </div>
                        </div>
                        <div className="form-group">
                            <div className="square-radio">
                                <input type="radio" className=""/>
                                <span className="text">This track does not have End Date</span>
                            </div>
                        </div>
                        <div className="form-group pt-3">
                            <label>Select Duration</label>
                            <input type="text" className="form-control"/>
                        </div>
                    </div>
                    <div className="col-12 col-md-6">
                        <input type="date" data-date-inline-picker="true" className="form-control" id="calendar" name="calendar" />
                    </div>
                </div>
            </div>
            <div className="row justify-content-center">
                <div className="col-sm-12">
                    <Stats step={2} {...props} previousStep={validate} />
                </div>
            </div>
        </div>
    );
};

const Third = props => {
    const validate = () => {
        if (confirm('Are you sure you want to go back?')) { // eslint-disable-line
            props.previousStep();
        }
    };
    return (
        <div>
            {/* { props.form.firstname && <h3>Hey {props.form.firstname}!</h3> } */}
            <div className="clearfix">
                <h3 className='modal-subeading text-center mb-5'>Type of class offered</h3>
                <div className="row justify-content-center">
                    <div className="col-12 col-md-8">
                        <div className="form-group">
                            <input type="text" className="form-control" placeholder="Enter Medium of Instruction"/>
                        </div>
                        <div className="clearfix form-group">
                            <label>Delivery Method</label>
                            <div className="row">
                                <div className="col-12 col-sm-6">
                                    <label htmlFor="delivery_online" className="btn-radio w-100">
                                        <input type="radio" id="delivery_online" name="delivery_method"/>
                                        <div className="btn-rdo-wrap">
                                            <span className="text">Online</span>
                                        </div>
                                    </label>
                                </div>
                                <div className="col-12 col-sm-6">
                                    <label htmlFor="delivery_offline" className="btn-radio w-100">
                                        <input type="radio" id="delivery_offline" name="delivery_method"/>
                                        <div className="btn-rdo-wrap">
                                            <span className="text">Offline</span>
                                        </div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div className="row justify-content-center">
                <div className="col-sm-8">
                    <Stats step={2} {...props} previousStep={validate} />
                </div>
            </div>
        </div>
    );
};

const Last = (props) => {
    const submit = () => {
        alert('You did it! Yay!') // eslint-disable-line
    };

    return (
        <div className="clearfix">
            <h3 className='modal-subeading text-center mb-5'>What is your fee?</h3>
            <div className="row justify-content-center">
                <div className="col-12 col-md-8">
                    <div className="input-group mb-4">
                        <input type="text" className="form-control" placeholder="Enter your rates per class" />
                        <div className="input-group-append">
                            <span className="input-group-text" id="basic-addon2"><i className="bx bx-rupee"></i> /hr</span>
                        </div>
                    </div>

                    <div className="toggle-text-wrap d-flex mb-4">
                        <div className="w-100">
                            First Class for free
                        </div>
                        <div className="toggler">
                            <label className="toggle">
                                <input type="checkbox" />
                                <span className="slider"></span>
                                <span className="labels" data-on="ON" data-off="OFF"></span>
                            </label>
                        </div>
                    </div>
                    <div className="form-group">
                        <label>When students can Enroll (Optional)</label>
                        <div className="col-12 px-0 mb-4">
                            <label htmlFor="enroll_after" className="btn-radio w-100">
                                <input type="radio" id="enroll_after" name="enroll_opt"/>
                                <div className="btn-rdo-wrap">
                                    <span className="text">Student must enroll after <span className="enroll-date">(01-09-2022)</span></span>
                                </div>
                            </label>
                        </div>
                        <div className="col-12 px-0 mb-4">
                            <label htmlFor="enroll_before" className="btn-radio w-100">
                                <input type="radio" id="enroll_before" name="enroll_opt"/>
                                <div className="btn-rdo-wrap">
                                <span className="text">Student must enroll before <span className="enroll-date">(01-09-2022)</span></span>
                                </div>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div className="row justify-content-center">
                <div className="col-sm-8">
                    <Stats step={4} {...props} nextStep={submit} />
                </div>
            </div>
        </div>
    );
};
