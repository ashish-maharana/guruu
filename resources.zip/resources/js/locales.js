exports.DEFAULT_LOCALE = 'en';

// prettier-ignore
exports.appLocales = [
    'en',
];
